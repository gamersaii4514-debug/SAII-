# SAII — Fases 1 a 9

Compilar: abrir la carpeta en Android Studio (Ladybug o superior, JDK 17) → Sync → Run en tu teléfono (depuración USB).
Por línea de comandos: `gradle wrapper` una vez, luego `./gradlew assembleDebug`.

Arquitectura y restricciones de Android: ver `ARQUITECTURA.md`.

Pruebas automáticas: `./gradlew testDebugUnitTest`. Plan de pruebas en el teléfono y limitaciones conocidas: `PRUEBAS.md`.
