# Réplica línea a línea de ClapAnalyzer.kt para validar la lógica con audio sintético.
import numpy as np
from math import sqrt
class A:
    def __init__(s, sens=50, maxgap=700, mingap=150, fm=20):
        s.ratio=12-sens*0.08; s.absmin=0.08-sens*0.0006; s.maxgap=min(max(maxgap,300),1200); s.mingap=mingap; s.fm=fm
        s.st='I'; s.t=0; s.warm=0; s.noise=0.005; s.prev=[0,0,0]; s.es=0; s.ef=0; s.q=0; s.cd=0; s.bl=0; s.f=-1; s.sec=-1
    def push(s,r): s.prev=[s.prev[1],s.prev[2],r]
    def reset(s): s.f=-1; s.sec=-1
    def onclap(s,start):
        if s.t<s.bl: return
        if s.sec>=0: s.reset(); s.bl=s.t+1500; return
        if s.f<0: s.f=start; return
        g=start-s.f
        if g<s.mingap: pass
        elif g<=s.maxgap: s.sec=start
        else: s.f=start
    def proc(s,x):
        r=sqrt(np.mean(x**2)); s.t+=s.fm
        if s.warm<25:
            s.warm+=1; s.noise=r if s.warm==1 else s.noise+(r-s.noise)/s.warm; s.noise=max(s.noise,0.002); s.push(r); return False
        thr=max(s.noise*s.ratio,s.absmin); pm=max(s.prev)
        if s.st=='I':
            if r>thr and r>2.5*pm: s.st='E'; s.es=s.t; s.ef=1
            else: s.noise+=0.02*(min(r,s.noise*3)-s.noise); s.noise=max(s.noise,0.002)
        elif s.st=='E':
            s.ef+=1
            if r<thr*0.5:
                if s.ef*s.fm<=160: s.onclap(s.es)
                s.st='C'; s.cd=s.t+80
            elif s.ef*s.fm>160: s.reset(); s.st='S'; s.q=0
        elif s.st=='S':
            s.noise+=0.05*(r-s.noise); s.noise=max(s.noise,0.002)
            s.q = s.q+1 if r<thr*0.5 else 0
            if s.q>=5: s.st='C'; s.cd=s.t+100
        else:
            if s.t>=s.cd: s.st='I'
        s.push(r)
        if s.sec>=0 and s.t-s.sec>=500 and s.st!='E': s.reset(); return True
        return False
SR=16000; rng=np.random.default_rng(1)
def base(sec,noise): return rng.normal(0,noise,int(SR*sec))
def clap(sig,at_ms,amp,tau=12):
    i=int(at_ms*SR/1000); n=int(0.15*SR); tt=np.arange(n)/SR*1000
    b=rng.normal(0,1,n)*np.exp(-tt/tau)*amp; sig[i:i+n]+=b[:len(sig)-i]
def speech(sig,at_ms,dur_ms,amp):
    i=int(at_ms*SR/1000); n=int(dur_ms*SR/1000); tt=np.arange(n)/SR
    env=0.6+0.4*np.sin(2*np.pi*4*tt)
    v=sum(np.sin(2*np.pi*150*k*tt)/k for k in range(1,8)); v=v/np.max(np.abs(v))*amp*env
    sig[i:i+n]+=v
def run(sig,**kw):
    a=A(**kw); n=0; 
    for k in range(0,len(sig)-320,320):
        if a.proc(np.clip(sig[k:k+320],-1,1)): n+=1
    return n
def case(name,build,expect,noise=0.005,**kw):
    ok=0; T=20
    for _ in range(T):
        s=base(4,noise); build(s); ok+= (run(s,**kw)>=1)
    print(f"{name:44s} detecta {ok:2d}/{T}  esperado: {expect}")
case("doble aplauso fuerte, gap 350ms",lambda s:(clap(s,1000,0.6),clap(s,1350,0.6)),"20/20")
case("doble aplauso suave (amp .2), gap 400ms",lambda s:(clap(s,1000,0.2),clap(s,1400,0.2)),"alto")
case("doble aplauso con ruido ambiente .02",lambda s:(clap(s,1000,0.6),clap(s,1400,0.6)),"20/20",noise=0.02)
case("gap 600ms (límite normal)",lambda s:(clap(s,1000,0.6),clap(s,1600,0.6)),"20/20")
case("UN solo aplauso",lambda s:clap(s,1000,0.6),"0/20")
case("golpes pegados (gap 80ms, eco)",lambda s:(clap(s,1000,0.6),clap(s,1080,0.6)),"0/20")
case("gap 1000ms (demasiado separado)",lambda s:(clap(s,1000,0.6),clap(s,2000,0.6)),"0/20")
case("TRES aplausos (público)",lambda s:(clap(s,1000,0.6),clap(s,1350,0.6),clap(s,1700,0.6)),"0/20")
case("voz sostenida 1.2 s, amp .3",lambda s:speech(s,1000,1200,0.3),"0/20")
case("voz fuerte + habla corta 100ms",lambda s:speech(s,1000,100,0.5),"?")
case("música/tono continuo, amp .3",lambda s:speech(s,500,3000,0.3),"0/20")
case("ruido de fondo solo",lambda s:None,"0/20")
case("doble aplauso con sens=10 (poco sensible), suave .2",lambda s:(clap(s,1000,0.2),clap(s,1400,0.2)),"bajo",sens=10)
case("doble aplauso con sens=90, suave .1",lambda s:(clap(s,1000,0.1),clap(s,1400,0.1)),"alto",sens=90)
# falsos positivos en 10 minutos de ruido + habla alterna
fp=0
for _ in range(5):
    s=base(120,0.008)
    for st in range(2000,115000,6000): speech(s,st,rng.integers(500,2500),rng.uniform(0.1,0.4))
    fp+=run(s)
print("falsos positivos en 10 min de habla+ruido:",fp)
