package com.saii.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.saii.app.core.SaiiViewModel
import com.saii.app.phone.Apps
import com.saii.app.security.PermissionEntry
import com.saii.app.security.PermissionRegistry

private data class Integration(
    val name: String,
    val ok: Boolean,          // lista para usar
    val status: String,
    val detail: String,
    val action: (@Composable () -> Unit)? = null,
)

/** Administrador de integraciones: estado REAL de cada conexión y qué hace (y qué no) SAII con ella. */
@Composable
fun IntegrationsScreen(vm: SaiiViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("saii_settings", Context.MODE_PRIVATE) }
    var tick by remember { mutableIntStateOf(0) }
    var web by remember { mutableStateOf(prefs.getBoolean("websearch", true)) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val calLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    // Lectura barata (getPackageInfo); se recalcula al volver a la pantalla porque `tick` cambia.
    fun app(name: String, pkg: String, detail: String): Integration {
        val inst = tick >= 0 && Apps.installed(ctx, pkg)
        return Integration(name, inst, if (inst) "Instalada" else "No instalada", detail)
    }

    val calGranted = remember(tick) {
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED
    }
    val notifEntry = PermissionRegistry.entries.first { it.permission == PermissionRegistry.NOTIFICATION_LISTENER_KEY }
    val notifOn = remember(tick) { PermissionRegistry.isGranted(ctx, notifEntry) }

    val items = listOf(
        app("WhatsApp", Apps.WHATSAPP, "Deja el mensaje preparado en el chat del contacto. Tú tocas «enviar» (WhatsApp no ofrece API para enviar por ti)."),
        app("Telegram", Apps.TELEGRAM, "Abre Telegram con el texto listo; eliges el chat y tocas «enviar»."),
        app("Messenger", Apps.MESSENGER, "Abre Messenger con el texto listo; eliges el chat y tocas «enviar»."),
        app("Facebook", Apps.FACEBOOK, "Solo abrir la aplicación. No hay API pública para publicar en tu nombre."),
        app("YouTube", Apps.YOUTUBE, "Abre los resultados de una búsqueda; tú eliges el video."),
        app("Spotify", Apps.SPOTIFY, "Pide reproducir una canción o artista; no puede verificar qué suena."),
        app("YouTube Music", Apps.YT_MUSIC, "Pide reproducir una canción o artista; no puede verificar qué suena."),
        app("Google Maps", Apps.MAPS, "Navegar a un destino y buscar lugares."),
        app("Gmail", Apps.GMAIL, "Solo prepara borradores (tú envías). Leer o buscar correos requiere la API de Google, no configurada."),
        Integration(
            "Calendario", calGranted, if (calGranted) "Autorizado" else "Sin permiso",
            "Lee tus próximos eventos (incluye Google Calendar si está sincronizado) y prepara eventos nuevos para que tú los guardes.",
            action = if (calGranted) null else ({ Button(onClick = { calLauncher.launch(Manifest.permission.READ_CALENDAR) }) { Text("Autorizar") } }),
        ),
        Integration(
            "Notificaciones", notifOn, if (notifOn) "Acceso activado" else "Acceso desactivado",
            "Cuando se lo pidas, lee las últimas notificaciones. Solo se guardan en memoria (máx. 50) y su texto viaja al modelo de IA únicamente al consultarlas.",
            action = {
                OutlinedButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }) { Text(if (notifOn) "Revocar en Ajustes" else "Activar en Ajustes") }
            },
        ),
        app("Google Home", Apps.HOME, "NO disponible: controlar luces y dispositivos requiere las Home APIs de Google (registro de desarrollador y autorización OAuth)."),
        app("Google Drive", Apps.DRIVE, "NO disponible: acceder a tus archivos requiere la API de Google (OAuth), no configurada."),
    )

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TextButton(onClick = onBack) { Text("‹ SAII") }
        Text("Aplicaciones conectadas", style = MaterialTheme.typography.headlineSmall)
        Text(
            "SAII usa solo mecanismos oficiales de Android y de cada app. Donde no existe una API pública, deja la acción preparada y tú la completas.",
            style = MaterialTheme.typography.bodySmall,
        )
        Spacer(Modifier.height(8.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Búsqueda en Internet", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            Switch(checked = web, onCheckedChange = { web = it; vm.setWebSearch(it) })
                        }
                        Text(
                            "El modelo busca en la web para información actual (hasta 3 búsquedas por consulta). " +
                                "Se factura en tu cuenta de la API (≈ 10 USD por cada 1000 búsquedas) y debe estar habilitada en tu consola de Anthropic; " +
                                "si no lo está, SAII sigue funcionando sin ella.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
            items(items) { i ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(i.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            Text(
                                i.status, style = MaterialTheme.typography.labelMedium,
                                color = if (i.ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            )
                        }
                        Text(i.detail, style = MaterialTheme.typography.bodySmall)
                        i.action?.let { Box(Modifier.padding(top = 6.dp)) { it() } }
                    }
                }
            }
        }
    }
}
