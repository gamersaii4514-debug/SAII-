package com.saii.app.activation

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.saii.app.MainActivity
import com.saii.app.R
import com.saii.app.ai.BrainResult
import com.saii.app.ai.Confirmer
import android.content.IntentFilter
import android.os.BatteryManager
import com.saii.app.core.Net
import com.saii.app.memory.ContextProvider
import com.saii.app.phone.OfflineCommands
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineExceptionHandler
import org.json.JSONObject
import com.saii.app.phone.PhoneTools
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import com.saii.app.ai.ClaudeBrain
import com.saii.app.core.ConversationRepository
import com.saii.app.core.Message
import com.saii.app.core.Role
import com.saii.app.storage.KeyVault
import com.saii.app.voice.VoiceEngine
import com.saii.app.voice.VoiceError
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * SAII_Activation. Servicio en primer plano (tipo micrófono) que escucha «Hey SAII» / «Oye SAII» / «SAII»
 * con el reconocedor de voz del sistema, responde «A sus órdenes», atiende la orden con el cerebro y
 * mantiene la conversación sin repetir la palabra de activación hasta que haya silencio o el usuario la cierre.
 *
 * Mientras la aplicación SAII está visible el servicio se pausa (la interfaz usa el micrófono).
 */
class WakeService : Service() {

    companion object {
        const val ACTION_STOP = "com.saii.app.WAKE_STOP"
        private const val CHANNEL = "saii_wake"
        private const val NOTIF_ID = 1001

        private val _active = MutableStateFlow(false)
        val active: StateFlow<Boolean> = _active.asStateFlow()

        @Volatile private var instance: WakeService? = null
        @Volatile private var uiVisible = false

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, WakeService::class.java))
        }

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, WakeService::class.java)) }

        /** true mientras la interfaz de SAII está en pantalla. */
        val isUiVisible: Boolean get() = uiVisible

        /** Reaplica los ajustes de activación (método, sensibilidad…) si el servicio está en reposo. */
        fun reload() {
            instance?.let { s ->
                s.main.post {
                    if (!uiVisible && !s.inSession) { s.epoch++; s.stopClap(); s.voice.stopListening(); s.startWakeLoop() }
                }
            }
        }

        /** Llamado desde la actividad (hilo principal) en onStart/onStop. */
        fun setUiVisible(visible: Boolean) {
            uiVisible = visible
            instance?.let { if (visible) it.pauseInternal() else it.resumeInternal() }
        }
    }

    private val main = Handler(Looper.getMainLooper())
    // Un fallo inesperado en una corrutina cierra la sesión manos libres en vez de tumbar la aplicación.
    private val scope = CoroutineScope(
        SupervisorJob() + Dispatchers.Main + CoroutineExceptionHandler { _, _ -> main.post { endSession() } }
    )
    private lateinit var voice: VoiceEngine
    private var wakeLock: PowerManager.WakeLock? = null
    private var clap: ClapDetector? = null

    private var epoch = 0            // invalida callbacks atrasados
    private var inSession = false
    private var sessionConv: String? = null
    private var errorStreak = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Activación por voz", NotificationManager.IMPORTANCE_LOW)
        )
        voice = VoiceEngine(this)
        scope.launch(Dispatchers.IO) { ConversationRepository.init(this@WakeService) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences("saii_settings", MODE_PRIVATE).edit().putBoolean("wake_enabled", false).apply()
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            ServiceCompat.startForeground(
                this, NOTIF_ID, buildNotif(if (uiVisible) PAUSED_TEXT else LISTEN_TEXT),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE,
            )
        } catch (e: Exception) {
            // Android no permite iniciar el micrófono en segundo plano desde este contexto.
            stopSelf()
            return START_NOT_STICKY
        }
        if (instance == null) {
            instance = this
            _active.value = true
            wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "saii:wake").apply { setReferenceCounted(false); acquire() }
            startWakeLoop()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        epoch++
        stopClap()
        voice.shutdown()
        scope.cancel()
        wakeLock?.let { if (it.isHeld) it.release() }
        instance = null
        _active.value = false
        super.onDestroy()
    }

    // ---------- Bucle de escucha de la palabra de activación ----------

    private fun startWakeLoop() {
        if (uiVisible || inSession) return
        val my = ++epoch
        stopClap()
        if (lowBattery()) {      // ahorro: no se escucha con batería ≤ 15 % si no está cargando
            updateNotif("En pausa: batería baja (≤ 15 %)")
            restartWake(60_000)
            return
        }
        if (settings().getBoolean("clap_enabled", false)) { startClapMode(my); return }
        updateNotif(LISTEN_TEXT)
        voice.listen(
            onPartial = { if (my == epoch && WakeWord.matches(it)) onWake() },
            onResult = { if (my == epoch) { if (WakeWord.matches(it)) onWake() else restartWake(250) } },
            onError = { e -> if (my == epoch) handleWakeError(e) },
        )
    }

    private fun lowBattery(): Boolean {
        val st = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return false
        val level = st.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = st.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val status = st.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        return !charging && level >= 0 && scale > 0 && level * 100 / scale <= 15
    }

    private fun restartWake(delayMs: Long) {
        val my = epoch
        main.postDelayed({ if (my == epoch) startWakeLoop() }, delayMs)
    }

    private fun handleWakeError(e: VoiceError) {
        when (e) {
            VoiceError.NO_SPEECH -> { errorStreak = 0; restartWake(200) }
            VoiceError.BUSY -> restartWake(1000)
            VoiceError.PERMISSION, VoiceError.UNAVAILABLE -> {
                updateNotif(e.message)
                getSharedPreferences("saii_settings", MODE_PRIVATE).edit().putBoolean("wake_enabled", false).apply()
                stopSelf()
            }
            else -> {   // red caída u otro fallo: espera creciente para no gastar batería en vano
                errorStreak++
                restartWake(minOf(2000L * errorStreak, 30_000L))
            }
        }
    }

    // ---------- Modo dos aplausos ----------
    // El micrófono no se puede compartir entre el detector de aplausos y el reconocedor de voz, por eso
    // en este modo «Hey SAII» no escucha en reposo: primero se detectan los aplausos (ligero) y solo
    // entonces se enciende el reconocimiento de voz.

    private fun settings() = getSharedPreferences("saii_settings", MODE_PRIVATE)

    private fun stopClap() { clap?.stop(); clap = null }

    private fun startClapMode(my: Int) {
        updateNotif(CLAP_TEXT)
        val p = settings()
        val d = ClapDetector(
            sensitivity = p.getInt("clap_sens", 50),
            maxGapMs = p.getInt("clap_gap", 700),
            onDoubleClap = { if (my == epoch) onClaps() },
            onError = { msg ->
                if (my == epoch) {
                    errorStreak++
                    updateNotif(msg)
                    restartWake(minOf(3000L * errorStreak, 30_000L))
                }
            },
        )
        clap = d
        d.start()
    }

    private fun onClaps() {
        epoch++
        stopClap()
        inSession = true
        errorStreak = 0
        if (settings().getBoolean("clap_need_saii", true)) {
            updateNotif("Dos aplausos: di «SAII»…")
            listenForName()
        } else {
            updateNotif("Dos aplausos detectados")
            say("Aquí estoy, dime.") { listenCommand() }
        }
    }

    private fun listenForName() {
        val my = ++epoch
        voice.listen(
            onPartial = {},
            onResult = { text ->
                if (my == epoch) {
                    if (WakeWord.matches(text)) {
                        val rest = WakeWord.stripWake(text)
                        if (rest.isNotBlank()) handleCommand(rest) else say("Aquí estoy, dime.") { listenCommand() }
                    } else endSession()
                }
            },
            onError = { if (my == epoch) endSession() },
        )
    }

    // ---------- Sesión manos libres ----------

    private fun onWake() {
        epoch++
        voice.stopListening()
        inSession = true
        errorStreak = 0
        updateNotif("Te escucho…")
        say("A sus órdenes") { listenCommand() }
    }

    private fun listenCommand() {
        val my = ++epoch
        updateNotif("Escuchando tu orden…")
        voice.listen(
            onPartial = {},
            onResult = { text -> if (my == epoch) handleCommand(text) },
            onError = { if (my == epoch) endSession() },
        )
    }

    private fun handleCommand(text: String) {
        val my = ++epoch
        if (WakeWord.isEndPhrase(text)) { say("Aquí estaré.") { endSession() }; return }

        ConversationRepository.init(this)   // idempotente: asegura que el historial esté cargado antes de añadir
        val id = sessionConv ?: ConversationRepository.create().also { sessionConv = it }
        ConversationRepository.append(id, Message(role = Role.USER, text = text), titleFrom = text)
        updateNotif("Pensando…")

        scope.launch {
            val key = withContext(Dispatchers.IO) { KeyVault(this@WakeService).load() }
            val online = Net.isOnline(this@WakeService)
            val tools = PhoneTools(this@WakeService, confirmer, onState = { updateNotif(it.label) })
            // Sin conexión (o sin clave) se atienden las órdenes simples del teléfono con reglas locales.
            val local = if (!online || key.isNullOrBlank()) OfflineCommands.parse(text) else null
            val (reply, isError) = try {
                when {
                    local != null -> tools.run(local.tool, JSONObject(local.args)).let { it.text to it.isError }
                    key.isNullOrBlank() ->
                        "Aún no tengo la clave de inteligencia artificial. Añádela en la aplicación, en Cerebro de IA." to true
                    !online -> OfflineCommands.HELP to true
                    else -> when (val r = ClaudeBrain(
                        key, tools, settings().getBoolean("websearch", true),
                        extraContext = { ContextProvider.build(this@WakeService) },
                    ).reply(ConversationRepository.messages(id))) {
                        is BrainResult.Text -> r.text to false
                        is BrainResult.Unavailable -> r.reason to true
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                "No pude completar la respuesta." to true
            }
            if (my != epoch) return@launch   // cancelada por pausa o cierre
            ConversationRepository.append(id, Message(role = Role.SAII, text = reply, error = isError))
            withContext(Dispatchers.IO) { ConversationRepository.save() }
            if (my != epoch) return@launch
            updateNotif("Hablando…")
            say(reply) { if (isError) endSession() else listenCommand() }
        }
    }

    private fun endSession() {
        inSession = false
        sessionConv = null
        epoch++
        voice.stopListening()
        restartWake(500)
    }

    /** Habla y luego ejecuta [then]; si no hay voz disponible, continúa directamente. */
    private fun say(text: String, then: () -> Unit) {
        val my = epoch
        val started = voice.speak(text) { if (my == epoch) then() }
        if (!started) then()
    }

    // ---------- Confirmación por voz de acciones sensibles ----------
    // Ante cualquier duda (silencio, respuesta no entendida, pausa) se responde «no».

    private var confirmToken = 0
    private var confirmCont: CancellableContinuation<Boolean>? = null

    private val confirmer = object : Confirmer {
        override suspend fun confirm(summary: String): Boolean = suspendCancellableCoroutine { cont ->
            val token = ++confirmToken
            confirmCont = cont
            cont.invokeOnCancellation {
                main.post { if (confirmToken == token) { confirmCont = null; confirmToken++; voice.stopListening() } }
            }
            updateNotif("Esperando tu confirmación…")
            say("$summary. ¿Confirmas?") {
                if (token == confirmToken) {
                    voice.listen(
                        onPartial = {},
                        onResult = { text -> if (token == confirmToken) finishConfirm(WakeWord.yesNo(text) == true) },
                        onError = { if (token == confirmToken) finishConfirm(false) },
                    )
                }
            }
        }
    }

    private fun finishConfirm(ok: Boolean) {
        val c = confirmCont
        confirmCont = null
        confirmToken++
        if (c != null && c.isActive) c.resume(ok)
    }

    // ---------- Pausa mientras la interfaz está visible ----------

    private fun pauseInternal() {
        if (confirmCont != null) finishConfirm(false)
        epoch++
        stopClap()
        voice.stopListening()
        voice.stopSpeaking()
        inSession = false
        sessionConv = null
        updateNotif(PAUSED_TEXT)
    }

    private fun resumeInternal() {
        if (!inSession) startWakeLoop()
    }

    // ---------- Notificación ----------

    private fun buildNotif(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WakeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_saii)
            .setContentTitle("SAII activo")
            .setContentText(text)
            .setContentIntent(open)
            .addAction(0, "Detener", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun updateNotif(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotif(text))
    }

    private val LISTEN_TEXT = "Escuchando «Hey SAII»…"
    private val PAUSED_TEXT = "En pausa: SAII está abierta"
    private val CLAP_TEXT = "Esperando dos aplausos…"
}
