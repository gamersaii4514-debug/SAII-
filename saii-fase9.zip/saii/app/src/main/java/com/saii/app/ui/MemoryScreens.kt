package com.saii.app.ui

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.saii.app.core.SaiiViewModel
import com.saii.app.memory.ActivityLog
import com.saii.app.memory.MemoryStore
import com.saii.app.memory.RoutineStore
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
private fun Header(title: String, onBack: () -> Unit, subtitle: String? = null) {
    TextButton(onClick = onBack) { Text("‹ SAII") }
    Text(title, style = MaterialTheme.typography.headlineSmall)
    subtitle?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    Spacer(Modifier.height(8.dp))
}

private val cardColors @Composable get() = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)

// ---------------------------------------------------------------- Memoria

@Composable
fun MemoryScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    remember { MemoryStore.init(ctx) }
    val version by MemoryStore.version.collectAsStateWithLifecycle()
    val list = remember(version) { MemoryStore.all() }
    val prefs = remember { ctx.getSharedPreferences("saii_settings", Context.MODE_PRIVATE) }

    var enabled by remember { mutableStateOf(prefs.getBoolean("memory_enabled", true)) }
    var newText by remember { mutableStateOf("") }
    var newCat by remember { mutableStateOf("dato") }
    var error by remember { mutableStateOf<String?>(null) }
    var editing by remember { mutableStateOf<MemoryStore.Item?>(null) }
    var editText by remember { mutableStateOf("") }
    var editError by remember { mutableStateOf<String?>(null) }
    var confirmAll by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Header(
            "Memoria", onBack,
            "Lo que SAII recuerda entre conversaciones. Solo vive en este teléfono; al usarlo, estos recuerdos se envían al modelo de IA " +
                "junto con tu mensaje. Nunca se guardan contraseñas ni números de tarjeta.",
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Usar y guardar recuerdos", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
            Switch(checked = enabled, onCheckedChange = { enabled = it; prefs.edit().putBoolean("memory_enabled", it).apply() })
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            item {
                Card(colors = cardColors) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Añadir recuerdo", style = MaterialTheme.typography.titleSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            MemoryStore.CATEGORIES.forEach { c ->
                                FilterChip(selected = newCat == c, onClick = { newCat = c }, label = { Text(c) })
                            }
                        }
                        OutlinedTextField(
                            value = newText, onValueChange = { newText = it; error = null },
                            modifier = Modifier.fillMaxWidth(), placeholder = { Text("Ej.: Prefiero respuestas cortas") },
                            maxLines = 3, keyboardOptions = KeyboardOptions.Default,
                        )
                        error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                        Button(enabled = newText.isNotBlank(), onClick = {
                            val r = MemoryStore.add(newCat, newText)
                            if (r.error == null) { newText = "" } else error = r.error
                        }) { Text("Guardar") }
                    }
                }
            }
            if (list.isEmpty()) item { Text("Aún no hay recuerdos.", style = MaterialTheme.typography.bodyMedium) }
            items(list, key = { it.id }) { m ->
                Card(colors = cardColors) {
                    Column(Modifier.padding(12.dp)) {
                        Text(m.category, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        Text(m.text)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { editing = m; editText = m.text; editError = null }) { Text("Editar") }
                            TextButton(onClick = { MemoryStore.remove(m.id) }) { Text("Borrar") }
                        }
                    }
                }
            }
        }
        if (list.isNotEmpty()) TextButton(onClick = { confirmAll = true }) { Text("Borrar todos los recuerdos") }
    }

    editing?.let { m ->
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Editar recuerdo") },
            text = {
                Column {
                    OutlinedTextField(value = editText, onValueChange = { editText = it; editError = null }, maxLines = 4)
                    editError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val e = MemoryStore.update(m.id, editText)
                    if (e == null) editing = null else editError = e
                }) { Text("Guardar") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancelar") } },
        )
    }
    if (confirmAll) {
        AlertDialog(
            onDismissRequest = { confirmAll = false },
            title = { Text("¿Borrar todos los recuerdos?") },
            text = { Text("Esta acción no se puede deshacer.") },
            confirmButton = { TextButton(onClick = { MemoryStore.clear(); confirmAll = false }) { Text("Borrar") } },
            dismissButton = { TextButton(onClick = { confirmAll = false }) { Text("Cancelar") } },
        )
    }
}

// ---------------------------------------------------------------- Historial de actividades

@Composable
fun ActivityScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    remember { ActivityLog.init(ctx) }
    val version by ActivityLog.version.collectAsStateWithLifecycle()
    val list = remember(version) { ActivityLog.all() }
    val fmt = remember { SimpleDateFormat("d MMM HH:mm", Locale("es")) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Header(
            "Historial de actividades", onBack,
            "Acciones que SAII ejecutó en tu teléfono (últimas 200). Los textos de mensajes y correos no se guardan aquí.",
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            if (list.isEmpty()) item { Text("Aún no hay actividad.") }
            items(list) { e ->
                Card(colors = cardColors) {
                    Column(Modifier.padding(12.dp)) {
                        Row {
                            Text(e.tool, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                            Text(
                                fmt.format(Date(e.ts)), style = MaterialTheme.typography.labelSmall,
                                color = if (e.error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                            )
                        }
                        if (e.args != "{}") Text(e.args, style = MaterialTheme.typography.labelSmall)
                        Text(e.result, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        if (list.isNotEmpty()) TextButton(onClick = { ActivityLog.clear() }) { Text("Borrar historial") }
    }
}

// ---------------------------------------------------------------- Automatizaciones

@Composable
fun AutomationsScreen(vm: SaiiViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    remember { RoutineStore.init(ctx) }
    val version by RoutineStore.version.collectAsStateWithLifecycle()
    val list = remember(version) { RoutineStore.all() }
    val scope = rememberCoroutineScope()
    var running by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Header(
            "Automatizaciones", onBack,
            "Rutinas: secuencias de acciones con nombre. Para crear una, pídeselo a SAII en el chat o por voz " +
                "(p. ej. «crea una rutina «voy a dormir» que baje el volumen y ponga una alarma a las 6:30»). " +
                "Se ejecutan cuando lo pides —diciendo su nombre o con el botón—, con tus permisos y confirmaciones. " +
                "Todavía no se programan por hora.",
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            if (list.isEmpty()) item { Text("Aún no hay rutinas.") }
            items(list, key = { it.id }) { r ->
                Card(colors = cardColors) {
                    Column(Modifier.padding(12.dp)) {
                        Text("«${r.name}»", style = MaterialTheme.typography.titleSmall)
                        if (r.description.isNotBlank()) Text(r.description, style = MaterialTheme.typography.bodySmall)
                        r.steps.forEachIndexed { i, s ->
                            Text(
                                "${i + 1}. ${s.tool}${if (s.args.length() > 0) " " + s.args.toString().take(80) else ""}" +
                                    (s.confirm?.let { "  (pregunta: $it)" } ?: ""),
                                style = MaterialTheme.typography.labelSmall,
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(enabled = !running, onClick = {
                                running = true; result = null
                                scope.launch { result = vm.runRoutine(r.name); running = false }
                            }) { Text(if (running) "Ejecutando…" else "Ejecutar") }
                            TextButton(enabled = !running, onClick = { RoutineStore.remove(r.id) }) { Text("Borrar") }
                        }
                    }
                }
            }
            result?.let { item { Card(colors = cardColors) { Text(it, Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall) } } }
        }
    }
}

// ---------------------------------------------------------------- Archivos y datos de SAII

@Composable
fun DataScreen(vm: SaiiViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var confirm by remember { mutableStateOf(false) }
    val files = remember(tick) { File(ctx.filesDir, "saii").listFiles()?.filter { it.isFile }?.sortedBy { it.name }.orEmpty() }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Header(
            "Archivos de SAII", onBack,
            "Todo lo que SAII guarda está en el almacenamiento privado de la app: ninguna otra aplicación puede leerlo. " +
                "La clave de API se guarda aparte, cifrada con el Keystore de Android.",
        )
        if (files.isEmpty()) Text("No hay archivos todavía.")
        files.forEach { f ->
            Card(colors = cardColors, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp)) {
                    Text(f.name, Modifier.weight(1f))
                    Text("${maxOf(1L, f.length() / 1024)} KB", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
        Spacer(Modifier.weight(1f))
        OutlinedButton(onClick = { confirm = true }) { Text("Borrar todos mis datos de SAII") }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("¿Borrar todos los datos?") },
            text = { Text("Se borran conversaciones, recuerdos, rutinas e historial. No se borra tu clave de API. No se puede deshacer.") },
            confirmButton = { TextButton(onClick = { vm.clearAllData(); confirm = false; tick++ }) { Text("Borrar") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancelar") } },
        )
    }
}
