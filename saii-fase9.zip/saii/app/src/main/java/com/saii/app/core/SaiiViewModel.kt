package com.saii.app.core

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.saii.app.ai.Brain
import com.saii.app.ai.BrainResult
import android.content.Context
import com.saii.app.ai.Confirmer
import com.saii.app.phone.OfflineCommands
import com.saii.app.memory.ActivityLog
import com.saii.app.memory.ContextProvider
import com.saii.app.memory.MemoryStore
import com.saii.app.memory.RoutineStore
import com.saii.app.phone.PhoneTools
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import com.saii.app.voice.VoiceEngine
import com.saii.app.ai.ClaudeBrain
import com.saii.app.ai.NoBrain
import com.saii.app.storage.KeyVault
import com.saii.app.storage.ConversationStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ConfirmRequest(val summary: String, val result: CompletableDeferred<Boolean>)

/** SAII_Core. Orquesta conversación, cerebro y estado. Toda acción futura pasará por aquí. */
class SaiiViewModel(app: Application) : AndroidViewModel(app) {

    // Confirmación de acciones sensibles (llamadas, SMS): la interfaz muestra un diálogo.
    private val _confirm = MutableStateFlow<ConfirmRequest?>(null)
    val pendingConfirm: StateFlow<ConfirmRequest?> = _confirm.asStateFlow()

    private val confirmer = object : Confirmer {
        override suspend fun confirm(summary: String): Boolean {
            val d = CompletableDeferred<Boolean>()
            _confirm.value = ConfirmRequest(summary, d)
            return try { withTimeoutOrNull(120_000) { d.await() } ?: false } finally { _confirm.value = null }
        }
    }

    fun answerConfirm(ok: Boolean) { _confirm.value?.result?.complete(ok) }

    private val vault = KeyVault(app)
    private val _brain = MutableStateFlow<Brain>(NoBrain())
    val brain: StateFlow<Brain> = _brain.asStateFlow()

    private fun refreshBrain() {
        val key = vault.load()
        _brain.value = if (key.isNullOrBlank()) NoBrain()
        else ClaudeBrain(
            key,
            tools,
            webSearch = getApplication<Application>().getSharedPreferences("saii_settings", Context.MODE_PRIVATE)
                .getBoolean("websearch", true),
            extraContext = { ContextProvider.build(getApplication<Application>()) },
        )
    }

    private val tools: PhoneTools by lazy {
        PhoneTools(getApplication<Application>(), confirmer, onState = { _state.value = it })
    }

    /** Ejecuta una rutina desde la pantalla de Automatizaciones (mismos permisos y confirmaciones). */
    suspend fun runRoutine(name: String): String {
        _state.value = SaiiState.EXECUTING
        return try {
            tools.run("run_routine", org.json.JSONObject().put("name", name)).text
        } finally {
            _state.value = SaiiState.IDLE
        }
    }

    /** Borra conversaciones, recuerdos, rutinas e historial. No toca la clave de API. */
    fun clearAllData() {
        _currentId.value = null
        ConversationRepository.clearAll()
        MemoryStore.clear()
        RoutineStore.clear()
        ActivityLog.clear()
    }

    fun setWebSearch(on: Boolean) {
        getApplication<Application>().getSharedPreferences("saii_settings", Context.MODE_PRIVATE)
            .edit().putBoolean("websearch", on).apply()
        refreshBrain()
    }

    fun saveKey(key: String) { vault.save(key.trim()); refreshBrain() }
    fun clearKey() { vault.clear(); refreshBrain() }

    /** Prueba real de conexión: una llamada mínima al modelo. Devuelve null si todo va bien, o el motivo del fallo. */
    suspend fun testBrain(): String? {
        val b = _brain.value
        if (!b.isConnected) return "Aún no has guardado una clave."
        val r = b.reply(listOf(Message(role = Role.USER, text = "Responde solo con la palabra OK.")))
        return (r as? BrainResult.Unavailable)?.reason
    }

    private val _conversations = ConversationRepository.flow
    val conversations: StateFlow<List<Conversation>> = _conversations.asStateFlow()

    private val _currentId = MutableStateFlow<String?>(null)
    val currentId: StateFlow<String?> = _currentId.asStateFlow()

    private val _state = MutableStateFlow(SaiiState.IDLE)
    val state: StateFlow<SaiiState> = _state.asStateFlow()

    init {
        refreshBrain()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { ConversationRepository.init(app) }
            _currentId.value = _conversations.value.firstOrNull()?.id
        }
    }

    fun newConversation() {
        val c = Conversation()
        _conversations.update { listOf(c) + it }
        _currentId.value = c.id
        persist()
    }

    fun select(id: String) { _currentId.value = id }

    fun deleteConversation(id: String) {
        _conversations.update { list -> list.filterNot { it.id == id } }
        if (_currentId.value == id) _currentId.value = _conversations.value.firstOrNull()?.id
        persist()
    }

    // ---- Voz (Fase 3) ----
    private var _voice: VoiceEngine? = null
    private val voice: VoiceEngine get() = _voice ?: VoiceEngine(getApplication()).also { _voice = it }
    private val settings = app.getSharedPreferences("saii_settings", Context.MODE_PRIVATE)

    private val _speakReplies = MutableStateFlow(settings.getBoolean("speak", true))
    val speakReplies: StateFlow<Boolean> = _speakReplies.asStateFlow()
    private val _continuous = MutableStateFlow(settings.getBoolean("continuous", false))
    val continuous: StateFlow<Boolean> = _continuous.asStateFlow()
    private val _partial = MutableStateFlow("")
    val partial: StateFlow<String> = _partial.asStateFlow()
    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice.asStateFlow()
    private var lastWasVoice = false

    fun clearNotice() { _notice.value = null }

    fun setSpeakReplies(v: Boolean) { _speakReplies.value = v; settings.edit().putBoolean("speak", v).apply() }
    fun setContinuous(v: Boolean) { _continuous.value = v; settings.edit().putBoolean("continuous", v).apply() }

    /** Requiere que el permiso de micrófono ya esté concedido (la interfaz lo solicita). */
    fun startListening() {
        if (_state.value == SaiiState.THINKING || _state.value == SaiiState.EXECUTING) return
        voice.stopSpeaking()
        _partial.value = ""
        _state.value = SaiiState.LISTENING
        voice.listen(
            onPartial = { _partial.value = it },
            onResult = { text ->
                _partial.value = ""
                _state.value = SaiiState.IDLE
                send(text, fromVoice = true)
            },
            onError = { e ->
                _partial.value = ""
                _state.value = SaiiState.IDLE
                lastWasVoice = false
                _notice.value = e.message
            },
        )
    }

    /** Cancela escucha o habla en curso y corta la conversación continua. */
    fun stopVoice() {
        _voice?.stopListening()
        _voice?.stopSpeaking()
        lastWasVoice = false
        _partial.value = ""
        if (_state.value == SaiiState.LISTENING || _state.value == SaiiState.SPEAKING) _state.value = SaiiState.IDLE
    }

    override fun onCleared() { _voice?.shutdown() }

    fun send(text: String, fromVoice: Boolean = false) {
        val clean = text.trim()
        if (clean.isEmpty() || _state.value == SaiiState.THINKING || _state.value == SaiiState.EXECUTING) return
        if (_state.value == SaiiState.LISTENING || _state.value == SaiiState.SPEAKING) stopVoice()
        lastWasVoice = fromVoice
        if (_currentId.value == null) newConversation()
        val id = _currentId.value!!

        append(id, Message(role = Role.USER, text = clean), titleFrom = clean)
        _state.value = SaiiState.THINKING

        viewModelScope.launch {
            val history = _conversations.value.firstOrNull { it.id == id }?.messages
            if (history == null) { _state.value = SaiiState.IDLE; return@launch }   // la conversación se borró
            val online = Net.isOnline(getApplication<Application>())
            val b = _brain.value
            // Sin conexión (o sin clave) se atienden las órdenes simples del teléfono con reglas locales.
            val local = if (!online || !b.isConnected) OfflineCommands.parse(clean) else null
            val (reply, isError) = try {
                when {
                    local != null -> tools.run(local.tool, org.json.JSONObject(local.args)).let { it.text to it.isError }
                    b.isConnected && !online -> OfflineCommands.HELP to true
                    else -> when (val r = b.reply(history)) {
                        is BrainResult.Text -> r.text to false
                        is BrainResult.Unavailable -> r.reason to true
                    }
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                "No pude completar la respuesta: ${e.message ?: "error desconocido"}." to true
            }
            append(id, Message(role = Role.SAII, text = reply, error = isError))
            _state.value = SaiiState.IDLE

            if (!isError && _speakReplies.value) {
                _state.value = SaiiState.SPEAKING
                val started = voice.speak(reply) {
                    if (_state.value == SaiiState.SPEAKING) {
                        _state.value = SaiiState.IDLE
                        if (_continuous.value && lastWasVoice) startListening()
                    }
                }
                if (!started) {
                    _state.value = SaiiState.IDLE
                    _notice.value = "No hay una voz en español instalada en el teléfono (Ajustes › Texto a voz)."
                }
            } else if (!isError && _continuous.value && lastWasVoice) {
                startListening()
            }
        }
    }

    private fun append(id: String, m: Message, titleFrom: String? = null) {
        _conversations.update { list ->
            list.map { c ->
                if (c.id != id) c else c.copy(
                    title = if (c.messages.isEmpty() && titleFrom != null) titleFrom.take(40) else c.title,
                    messages = c.messages + m,
                    updatedAt = m.ts,
                )
            }.sortedByDescending { it.updatedAt }
        }
        persist()
    }

    private fun persist() {
        viewModelScope.launch(Dispatchers.IO) { ConversationRepository.save() }
    }
}
