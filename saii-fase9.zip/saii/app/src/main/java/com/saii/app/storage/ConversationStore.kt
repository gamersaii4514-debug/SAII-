package com.saii.app.storage

import android.content.Context
import com.saii.app.core.Conversation
import com.saii.app.core.Message
import com.saii.app.core.Role
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** SAII_Storage. Persistencia local en el almacenamiento privado de la app (JSON, escritura atómica). */
class ConversationStore(context: Context) {
    private val file = File(context.filesDir, "saii/conversations.json")

    fun load(): List<Conversation> {
        if (!file.exists()) return emptyList()
        return try {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val msgs = o.getJSONArray("messages")
                Conversation(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    updatedAt = o.getLong("updatedAt"),
                    messages = (0 until msgs.length()).map { j ->
                        val m = msgs.getJSONObject(j)
                        Message(
                            id = m.getString("id"),
                            role = Role.valueOf(m.getString("role")),
                            text = m.getString("text"),
                            ts = m.getLong("ts"),
                            error = m.optBoolean("error", false),
                        )
                    },
                )
            }
        } catch (e: Exception) {
            // Archivo dañado: se conserva una copia y se empieza limpio.
            file.renameTo(File(file.parentFile, "conversations.corrupt.${System.currentTimeMillis()}.json"))
            emptyList()
        }
    }

    fun save(conversations: List<Conversation>) {
        file.parentFile?.mkdirs()
        val arr = JSONArray()
        conversations.forEach { c ->
            arr.put(JSONObject().apply {
                put("id", c.id)
                put("title", c.title)
                put("updatedAt", c.updatedAt)
                put("messages", JSONArray().apply {
                    c.messages.forEach { m ->
                        put(JSONObject().apply {
                            put("id", m.id); put("role", m.role.name)
                            put("text", m.text); put("ts", m.ts); put("error", m.error)
                        })
                    }
                })
            })
        }
        val tmp = File(file.parentFile, "conversations.tmp")
        tmp.writeText(arr.toString())
        if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file) }
    }
}
