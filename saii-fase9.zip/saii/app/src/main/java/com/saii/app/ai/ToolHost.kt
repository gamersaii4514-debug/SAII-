package com.saii.app.ai

import org.json.JSONArray
import org.json.JSONObject

data class ToolResult(val text: String, val isError: Boolean = false)

/** Quien ejecuta las herramientas que el cerebro pide (SAII_Android). */
interface ToolHost {
    /** Definición de herramientas en el formato de la API (name, description, input_schema). */
    fun specs(): JSONArray
    suspend fun run(name: String, input: JSONObject): ToolResult
}

/** Pide al usuario confirmar una acción sensible. Debe devolver false ante cualquier duda. */
interface Confirmer {
    suspend fun confirm(summary: String): Boolean
}
