package com.saii.app.memory

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** SAII_Automation. Rutinas: secuencias con nombre de acciones que SAII ejecuta cuando el usuario lo pide. */
object RoutineStore {
    data class Step(val tool: String, val args: JSONObject, val confirm: String?)
    data class Routine(val id: String, val name: String, val description: String, val steps: List<Step>)

    const val MAX_ROUTINES = 20
    const val MAX_STEPS = 10

    private val items = mutableListOf<Routine>()
    private var file: File? = null
    private var loaded = false
    private val _version = MutableStateFlow(0)
    val version: StateFlow<Int> = _version.asStateFlow()

    @Synchronized
    fun init(ctx: Context) {
        if (loaded) return
        val f = File(ctx.applicationContext.filesDir, "saii/routines.json")
        file = f
        try {
            JsonFile.read(f)?.let { arr ->
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val st = o.getJSONArray("steps")
                    items.add(Routine(
                        o.getString("id"), o.getString("name"), o.optString("description"),
                        (0 until st.length()).map { j ->
                            val s = st.getJSONObject(j)
                            Step(s.getString("tool"), s.optJSONObject("args") ?: JSONObject(), s.optString("confirm").takeIf { it.isNotBlank() })
                        },
                    ))
                }
            }
        } catch (e: Exception) {
            items.clear()
        }
        loaded = true
    }

    private fun save() {
        val f = file ?: return
        val arr = JSONArray()
        items.forEach { r ->
            arr.put(JSONObject().put("id", r.id).put("name", r.name).put("description", r.description).put(
                "steps",
                JSONArray().also { sa ->
                    r.steps.forEach { s ->
                        sa.put(JSONObject().put("tool", s.tool).put("args", s.args).also { o -> s.confirm?.let { o.put("confirm", it) } })
                    }
                },
            ))
        }
        JsonFile.write(f, arr)
        _version.value++
    }

    @Synchronized fun all(): List<Routine> = items.toList()

    /** Busca por nombre exacto y, si no, por coincidencia parcial (sin acentos ni mayúsculas). */
    @Synchronized
    fun find(name: String): Routine? {
        val q = norm(name)
        if (q.isEmpty()) return null
        return items.firstOrNull { norm(it.name) == q }
            ?: items.firstOrNull { norm(it.name).contains(q) || q.contains(norm(it.name)) }
    }

    /** Crea o reemplaza (mismo nombre). Devuelve un error o null. */
    @Synchronized
    fun put(name: String, description: String, steps: List<Step>): String? {
        val n = name.trim()
        if (n.isEmpty() || n.length > 60) return "El nombre de la rutina debe tener entre 1 y 60 caracteres."
        if (steps.isEmpty()) return "La rutina necesita al menos un paso."
        if (steps.size > MAX_STEPS) return "Máximo $MAX_STEPS pasos por rutina."
        val i = items.indexOfFirst { norm(it.name) == norm(n) }
        val id = if (i >= 0) items[i].id else UUID.randomUUID().toString().take(6)
        val r = Routine(id, n, description.trim().take(200), steps)
        if (i >= 0) items[i] = r
        else {
            if (items.size >= MAX_ROUTINES) return "Ya hay $MAX_ROUTINES rutinas. Borra alguna."
            items.add(r)
        }
        save()
        return null
    }

    @Synchronized
    fun remove(id: String): Boolean {
        val removed = items.removeAll { it.id == id }
        if (removed) save()
        return removed
    }

    @Synchronized fun clear() { items.clear(); save() }

    private fun norm(s: String) = java.text.Normalizer.normalize(s.lowercase().trim(), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "").replace(Regex("\\s+"), " ")
}
