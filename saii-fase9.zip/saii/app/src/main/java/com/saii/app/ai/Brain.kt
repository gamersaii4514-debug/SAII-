package com.saii.app.ai

import com.saii.app.core.Message

sealed interface BrainResult {
    data class Text(val text: String) : BrainResult
    data class Unavailable(val reason: String) : BrainResult
}

/**
 * SAII_AI. Contrato del cerebro. La Fase 2 aporta la implementación real
 * (modelo de IA con herramientas). Hasta entonces solo existe [NoBrain],
 * que NO inventa respuestas.
 */
interface Brain {
    val isConnected: Boolean
    suspend fun reply(history: List<Message>): BrainResult
}

class NoBrain : Brain {
    override val isConnected = false
    override suspend fun reply(history: List<Message>): BrainResult =
        BrainResult.Unavailable(
            "Aún no tengo la clave de inteligencia artificial: añádela en Cerebro de IA. " +
                "Mientras tanto solo puedo ejecutar órdenes simples del teléfono, como la linterna, el volumen o abrir apps."
        )
}
