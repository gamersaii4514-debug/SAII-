package com.saii.app.core

import java.util.UUID

enum class Role { USER, SAII }

data class Message(
    val id: String = UUID.randomUUID().toString(),
    val role: Role,
    val text: String,
    val ts: Long = System.currentTimeMillis(),
    /** Aviso del sistema (p. ej. error de conexión). Se muestra pero no se envía al modelo. */
    val error: Boolean = false,
)

data class Conversation(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "Nueva conversación",
    val messages: List<Message> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis(),
)

/** Estado visible de SAII (indicadores de la interfaz). */
enum class SaiiState(val label: String) {
    IDLE("Listo"),
    LISTENING("Escuchando…"),
    SPEAKING("Hablando…"),
    THINKING("Pensando…"),
    EXECUTING("Ejecutando acción…"), // Fase 6+
}
