package com.saii.app.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

enum class VoiceError(val message: String) {
    NO_SPEECH("No te escuché. Toca Hablar para intentarlo de nuevo."),
    PERMISSION("Falta el permiso del micrófono. Autorízalo en Permisos."),
    NETWORK("El reconocimiento de voz necesita Internet o un paquete de voz sin conexión instalado."),
    BUSY("El reconocedor de voz está ocupado. Inténtalo de nuevo."),
    UNAVAILABLE("Este teléfono no tiene un servicio de reconocimiento de voz disponible."),
    OTHER("No pude reconocer la voz. Inténtalo de nuevo."),
}

/**
 * SAII_Voice. Reconocimiento (SpeechRecognizer) y síntesis (TextToSpeech) del sistema Android.
 * Todas las llamadas deben hacerse desde el hilo principal.
 */
class VoiceEngine(private val context: Context) {

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var spanishOk = false
    private var gen = 0
    private var pending: Pair<String, () -> Unit>? = null
    private var currentDone: (() -> Unit)? = null

    init {
        tts = TextToSpeech(context) { status ->
            val t = tts
            if (status == TextToSpeech.SUCCESS && t != null) {
                val candidates = listOf(Locale("es", "CO"), Locale("es", "MX"), Locale("es", "ES"), Locale("es"))
                spanishOk = candidates.any {
                    val r = t.setLanguage(it)
                    r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                }
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onError(utteranceId: String?) { finish(utteranceId) }
                    override fun onDone(utteranceId: String?) { finish(utteranceId) }
                })
                ttsReady = true
                pending?.let { (txt, done) ->
                    pending = null
                    if (!speak(txt, done)) main.post { done() }
                }
            } else {
                // Motor de voz no disponible: se libera cualquier respuesta en espera para no bloquear la interfaz.
                ttsReady = true
                spanishOk = false
                pending?.let { (_, done) -> pending = null; main.post { done() } }
            }
        }
    }

    private fun finish(utteranceId: String?) {
        main.post {
            if (utteranceId == gen.toString()) {
                val cb = currentDone; currentDone = null
                cb?.invoke()
            }
        }
    }

    /** true si la síntesis arrancó (o quedó en cola esperando al motor); false si no hay voz en español. */
    fun speak(text: String, onDone: () -> Unit): Boolean {
        val clean = text.replace(Regex("[*_#`>]"), "").trim().take(3900)
        if (clean.isEmpty()) return false
        if (!ttsReady) { pending = clean to onDone; return true }
        if (!spanishOk) return false
        gen++
        currentDone = onDone
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, gen.toString())
        return true
    }

    fun stopSpeaking() {
        pending = null
        currentDone = null
        gen++
        tts?.stop()
    }

    fun listen(onPartial: (String) -> Unit, onResult: (String) -> Unit, onError: (VoiceError) -> Unit) {
        stopListening()
        if (!SpeechRecognizer.isRecognitionAvailable(context)) { onError(VoiceError.UNAVAILABLE); return }

        val r = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()?.let(onPartial)
            }

            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                stopListening()
                if (text.isNullOrBlank()) onError(VoiceError.NO_SPEECH) else onResult(text)
            }

            override fun onError(error: Int) {
                stopListening()
                onError(
                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> VoiceError.NO_SPEECH
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> VoiceError.PERMISSION
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                        SpeechRecognizer.ERROR_SERVER -> VoiceError.NETWORK
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> VoiceError.BUSY
                        else -> VoiceError.OTHER
                    }
                )
            }
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-CO")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try {
            r.startListening(intent)
        } catch (e: SecurityException) {            // permiso de micrófono revocado
            stopListening(); onError(VoiceError.PERMISSION)
        } catch (e: Exception) {
            stopListening(); onError(VoiceError.OTHER)
        }
    }

    fun stopListening() {
        recognizer?.destroy()
        recognizer = null
    }

    fun shutdown() {
        stopListening()
        stopSpeaking()
        tts?.shutdown()
        tts = null
    }
}
