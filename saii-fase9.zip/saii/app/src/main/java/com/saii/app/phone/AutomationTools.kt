package com.saii.app.phone

import android.content.Context
import com.saii.app.ai.ToolResult
import com.saii.app.memory.ContextProvider
import com.saii.app.memory.MemoryStore
import com.saii.app.memory.RoutineStore
import org.json.JSONArray
import org.json.JSONObject

/**
 * SAII_Memory / SAII_Automation. Herramientas de memoria y rutinas.
 * Las rutinas solo pueden usar las herramientas del teléfono e integraciones ya existentes, y cada paso pasa por
 * los mismos permisos y confirmaciones que si el usuario lo pidiera por separado.
 */
class AutomationTools(private val ctx: Context, private val owner: PhoneTools) {

    companion object {
        val NAMES = setOf("remember", "recall", "forget", "create_routine", "delete_routine", "run_routine")
    }

    fun specs(): List<JSONObject> {
        val step = JSONObject().put("type", "object")
            .put("properties", JSONObject()
                .put("tool", pStr("Nombre de una herramienta existente"))
                .put("args", JSONObject().put("type", "object").put("description", "Argumentos de esa herramienta"))
                .put("confirm", pStr("Si se indica, SAII pregunta esto al usuario antes del paso y lo omite si dice que no")))
            .put("required", JSONArray(listOf("tool")))
        return listOf(
            toolSpec(
                "remember",
                "Guarda un recuerdo duradero sobre el usuario. Úsalo solo si el usuario lo pide («recuerda que…») o expresa una preferencia estable y clara. " +
                    "Nunca contraseñas ni números de tarjeta o cuenta.",
                listOf(
                    "text" to pStr("El recuerdo, en una frase corta"),
                    "category" to pChoice("preferencia, proyecto, rutina o dato", "preferencia", "proyecto", "rutina", "dato"),
                ),
                listOf("text"),
            ),
            toolSpec("recall", "Busca en todos los recuerdos guardados.", listOf("query" to pStr("Texto a buscar; vacío = los más recientes"))),
            toolSpec(
                "forget", "Borra un recuerdo por su id (#abc123) o por texto que lo identifique.",
                listOf("id" to pStr("Id del recuerdo"), "text" to pStr("Texto del recuerdo, si no tienes el id")),
            ),
            toolSpec(
                "create_routine",
                "Crea o reemplaza una rutina: secuencia de acciones con nombre que el usuario podrá lanzar diciendo su nombre. " +
                    "Solo con herramientas existentes; máx. 10 pasos.",
                listOf(
                    "name" to pStr("Nombre corto, p. ej. «voy a dormir»"),
                    "description" to pStr("Qué hace, en una frase"),
                    "steps" to JSONObject().put("type", "array").put("description", "Pasos en orden").put("items", step),
                ),
                listOf("name", "steps"),
            ),
            toolSpec("delete_routine", "Borra una rutina por nombre.", listOf("name" to pStr("Nombre de la rutina")), listOf("name")),
            toolSpec("run_routine", "Ejecuta una rutina guardada, paso a paso.", listOf("name" to pStr("Nombre de la rutina")), listOf("name")),
        )
    }

    suspend fun dispatch(name: String, a: JSONObject): ToolResult? = when (name) {
        "remember" -> remember(a)
        "recall" -> recall(a.optString("query"))
        "forget" -> forget(a)
        "create_routine" -> createRoutine(a)
        "delete_routine" -> deleteRoutine(a.optString("name"))
        "run_routine" -> runRoutine(a.optString("name"))
        else -> null
    }

    // ---------- Memoria ----------

    private fun memoryOn(): Boolean = ContextProvider.enabled(ctx)

    private fun remember(a: JSONObject): ToolResult {
        if (!memoryOn()) return ToolResult("La memoria está desactivada por el usuario; no se guardó nada.", true)
        MemoryStore.init(ctx)
        val r = MemoryStore.add(a.optString("category", "dato"), a.optString("text"))
        return if (r.item != null) ToolResult("Guardado el recuerdo #${r.item.id}: ${r.item.text}")
        else ToolResult(r.error ?: "No se pudo guardar.", true)
    }

    private fun recall(query: String): ToolResult {
        MemoryStore.init(ctx)
        val list = MemoryStore.search(query).take(15)
        return if (list.isEmpty()) ToolResult("No hay recuerdos que coincidan.")
        else ToolResult(list.joinToString("\n") { "#${it.id} [${it.category}] ${it.text}" })
    }

    private fun forget(a: JSONObject): ToolResult {
        MemoryStore.init(ctx)
        val id = a.optString("id").removePrefix("#").trim()
        if (id.isNotEmpty()) {
            return if (MemoryStore.remove(id)) ToolResult("Recuerdo #$id borrado.") else ToolResult("No existe el recuerdo #$id.", true)
        }
        val text = a.optString("text").trim()
        if (text.isEmpty()) return ToolResult("Falta el id o el texto del recuerdo.", true)
        val m = MemoryStore.search(text)
        return when {
            m.isEmpty() -> ToolResult("No encontré un recuerdo que coincida con «$text».", true)
            m.size > 1 -> ToolResult(
                "Hay varios recuerdos posibles: " + m.take(8).joinToString("; ") { "#${it.id} ${it.text}" } +
                    ". Pregunta al usuario cuál borrar.", true,
            )
            else -> { MemoryStore.remove(m[0].id); ToolResult("Recuerdo borrado: ${m[0].text}") }
        }
    }

    // ---------- Rutinas ----------

    private fun createRoutine(a: JSONObject): ToolResult {
        RoutineStore.init(ctx)
        val allowed = owner.routineToolNames()
        val arr = a.optJSONArray("steps") ?: return ToolResult("Faltan los pasos de la rutina.", true)
        val steps = mutableListOf<RoutineStore.Step>()
        for (i in 0 until arr.length()) {
            val s = arr.optJSONObject(i) ?: return ToolResult("El paso ${i + 1} no es válido.", true)
            val tool = s.optString("tool")
            if (tool !in allowed) {
                return ToolResult(
                    "El paso ${i + 1} usa «$tool», que no existe o no se puede usar en rutinas. " +
                        "Herramientas permitidas: ${allowed.sorted().joinToString(", ")}. Dile al usuario qué parte no es posible.", true,
                )
            }
            steps.add(RoutineStore.Step(tool, s.optJSONObject("args") ?: JSONObject(), s.optString("confirm").takeIf { it.isNotBlank() }))
        }
        val err = RoutineStore.put(a.optString("name"), a.optString("description"), steps)
        return if (err == null) ToolResult("Rutina «${a.optString("name").trim()}» guardada con ${steps.size} pasos.") else ToolResult(err, true)
    }

    private fun deleteRoutine(name: String): ToolResult {
        RoutineStore.init(ctx)
        val r = RoutineStore.find(name) ?: return ToolResult("No hay una rutina llamada «$name».", true)
        RoutineStore.remove(r.id)
        return ToolResult("Rutina «${r.name}» borrada.")
    }

    private suspend fun runRoutine(name: String): ToolResult {
        RoutineStore.init(ctx)
        val r = RoutineStore.find(name) ?: return ToolResult("No hay una rutina llamada «$name».", true)
        val allowed = owner.routineToolNames()
        val out = StringBuilder("Rutina «${r.name}»:\n")
        var failed = 0
        r.steps.forEachIndexed { i, s ->
            val n = i + 1
            if (s.tool !in allowed) {
                out.append("$n. ${s.tool}: no permitido en rutinas.\n"); failed++
                return@forEachIndexed
            }
            if (s.confirm != null && !owner.confirm(s.confirm)) {
                out.append("$n. ${s.tool}: omitido, el usuario no lo confirmó.\n")
                return@forEachIndexed
            }
            val res = owner.execute(s.tool, s.args)
            if (res.isError) failed++
            out.append("$n. ${s.tool}: ${res.text.take(160)}${if (res.isError) " (ERROR)" else ""}\n")
        }
        return ToolResult(out.toString().trim(), failed > 0 && failed == r.steps.size)
    }
}
