package com.saii.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.saii.app.activation.ClapDetector
import com.saii.app.activation.WakeService

@Composable
fun ActivationScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("saii_settings", Context.MODE_PRIVATE) }
    val active by WakeService.active.collectAsStateWithLifecycle()

    var clapOn by remember { mutableStateOf(prefs.getBoolean("clap_enabled", false)) }
    var sens by remember { mutableFloatStateOf(prefs.getInt("clap_sens", 50).toFloat()) }
    var gap by remember { mutableFloatStateOf(prefs.getInt("clap_gap", 700).toFloat()) }
    var needSaii by remember { mutableStateOf(prefs.getBoolean("clap_need_saii", true)) }
    var testing by remember { mutableStateOf(false) }
    var runId by remember { mutableIntStateOf(0) }
    var hits by remember { mutableIntStateOf(0) }
    var level by remember { mutableFloatStateOf(0f) }
    var testMsg by remember { mutableStateOf<String?>(null) }

    fun setClapMode(on: Boolean) {
        clapOn = on
        if (!on) testing = false
        prefs.edit().putBoolean("clap_enabled", on).apply()
        WakeService.reload()
    }

    // Prueba en vivo del detector (el servicio de fondo está en pausa mientras esta pantalla está abierta).
    DisposableEffect(testing, runId, sens.toInt(), gap.toInt()) {
        var det: ClapDetector? = null
        if (testing) {
            det = ClapDetector(
                sensitivity = sens.toInt(), maxGapMs = gap.toInt(),
                onDoubleClap = { hits++; runId++ },          // el detector es de un solo uso: se reinicia
                onError = { testMsg = it; testing = false },
                onLevel = { level = it },
            )
            det.start()
        }
        onDispose { det?.stop() }
    }
    val testMicLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { testMsg = null; testing = true }
    }

    fun enable() {
        prefs.edit().putBoolean("wake_enabled", true).apply()
        WakeService.start(ctx)
    }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { enable() }

    fun afterMic() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) else enable()
    }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) afterMic()
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TextButton(onClick = onBack) { Text("‹ SAII") }
        Text("Activación por voz", style = MaterialTheme.typography.headlineSmall)

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Escuchar «Hey SAII» en segundo plano", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (active) "Activo (aviso permanente en la barra de notificaciones)" else "Desactivado",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            Switch(
                checked = active,
                onCheckedChange = { on ->
                    if (on) {
                        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) afterMic()
                        else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    } else {
                        prefs.edit().putBoolean("wake_enabled", false).apply()
                        WakeService.stop(ctx)
                    }
                },
            )
        }

        Text(
            "Di «Hey SAII», «Oye SAII» o «SAII». Responderá «A sus órdenes», escuchará tu orden y seguirá la conversación " +
                "sin repetir la palabra hasta que haya silencio o digas «gracias» o «nada más».",
            style = MaterialTheme.typography.bodyMedium,
        )

        Text("Método de activación en segundo plano", style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !clapOn, onClick = { setClapMode(false) }, label = { Text("Hey SAII") })
            FilterChip(selected = clapOn, onClick = { setClapMode(true) }, label = { Text("Dos aplausos") })
        }
        Text(
            if (clapOn)
                "Con aplausos, SAII espera solo el sonido (mucho menos batería). Al oír dos aplausos enciende el reconocimiento de voz. " +
                    "En este modo «Hey SAII» no escucha en reposo, porque el micrófono no se puede compartir."
            else "Con «Hey SAII», el reconocimiento de voz escucha continuamente.",
            style = MaterialTheme.typography.bodySmall,
        )

        if (clapOn) {
            Text("Sensibilidad: ${sens.toInt()}", style = MaterialTheme.typography.labelLarge)
            Slider(
                value = sens, onValueChange = { sens = it }, valueRange = 0f..100f,
                onValueChangeFinished = { prefs.edit().putInt("clap_sens", sens.toInt()).apply(); WakeService.reload() },
            )
            Text("Intervalo máximo entre aplausos: ${gap.toInt()} ms", style = MaterialTheme.typography.labelLarge)
            Slider(
                value = gap, onValueChange = { gap = it }, valueRange = 300f..1000f,
                onValueChangeFinished = { prefs.edit().putInt("clap_gap", gap.toInt()).apply(); WakeService.reload() },
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Decir «SAII» después de aplaudir", modifier = Modifier.weight(1f))
                Switch(checked = needSaii, onCheckedChange = {
                    needSaii = it; prefs.edit().putBoolean("clap_need_saii", it).apply()
                })
            }
            Text(
                "Descarta sonidos largos (voz, música), un solo golpe, golpes muy juntos y aplausos de tres o más seguidos.",
                style = MaterialTheme.typography.bodySmall,
            )

            OutlinedButton(onClick = {
                if (testing) testing = false
                else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    testMsg = null; testing = true
                } else testMicLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }) { Text(if (testing) "Detener prueba" else "Probar aplausos") }
            if (testing) {
                LinearProgressIndicator(progress = { level }, modifier = Modifier.fillMaxWidth())
                Text("Dobles aplausos detectados: $hits", color = MaterialTheme.colorScheme.primary)
                Text("Ajusta la sensibilidad mientras pruebas: se aplica al instante.", style = MaterialTheme.typography.bodySmall)
            }
            testMsg?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Cosas que debes saber", style = MaterialTheme.typography.titleSmall)
                Text("• Gasta bastante batería: el micrófono y el reconocimiento de voz del sistema trabajan sin parar. Desactívalo cuando no lo uses.", style = MaterialTheme.typography.bodySmall)
                Text("• Necesita Internet salvo que tengas el paquete de voz en español sin conexión instalado.", style = MaterialTheme.typography.bodySmall)
                Text("• El reconocedor no conoce la palabra «SAII»: a veces la escribe distinto y no se activará, o se activará con sonidos parecidos.", style = MaterialTheme.typography.bodySmall)
                Text("• En algunos teléfonos se oye un pitido en cada reinicio del reconocedor.", style = MaterialTheme.typography.bodySmall)
                Text("• Mientras la app SAII está abierta, la escucha se pausa (usa el botón Hablar).", style = MaterialTheme.typography.bodySmall)
                Text("• Tras reiniciar el teléfono, Android no permite arrancar el micrófono solo: abre SAII una vez y se reactiva.", style = MaterialTheme.typography.bodySmall)
                Text("• Algunos fabricantes cierran servicios en segundo plano. Si deja de responder, excluye a SAII de la optimización de batería.", style = MaterialTheme.typography.bodySmall)
            }
        }

        OutlinedButton(onClick = {
            ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }) { Text("Ajustes de optimización de batería") }
    }
}
