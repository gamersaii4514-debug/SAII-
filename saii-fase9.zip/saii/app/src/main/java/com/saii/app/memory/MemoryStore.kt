package com.saii.app.memory

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * SAII_Memory. Recuerdos duraderos entre conversaciones (preferencias, proyectos, rutinas, datos).
 * Se guardan solo en el teléfono. El usuario puede verlos, editarlos y borrarlos; nunca se guardan
 * contraseñas ni números de tarjeta o cuenta.
 */
object MemoryStore {
    data class Item(val id: String, val category: String, val text: String, val ts: Long)
    data class AddResult(val item: Item?, val error: String?)

    val CATEGORIES = listOf("preferencia", "proyecto", "rutina", "dato")
    const val MAX_ITEMS = 200
    const val MAX_TEXT = 300

    private val items = mutableListOf<Item>()
    private var file: File? = null
    private var loaded = false
    private val _version = MutableStateFlow(0)
    /** Cambia cada vez que se modifica la memoria; la interfaz lo observa para refrescarse. */
    val version: StateFlow<Int> = _version.asStateFlow()

    @Synchronized
    fun init(ctx: Context) {
        if (loaded) return
        val f = File(ctx.applicationContext.filesDir, "saii/memory.json")
        file = f
        try {
            JsonFile.read(f)?.let { arr ->
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    items.add(Item(o.getString("id"), o.getString("category"), o.getString("text"), o.getLong("ts")))
                }
            }
        } catch (e: Exception) {
            items.clear()
        }
        loaded = true
    }

    private fun save() {
        val f = file ?: return
        val arr = JSONArray()
        items.forEach { arr.put(JSONObject().put("id", it.id).put("category", it.category).put("text", it.text).put("ts", it.ts)) }
        JsonFile.write(f, arr)
        _version.value++
    }

    @Synchronized fun all(): List<Item> = items.sortedByDescending { it.ts }

    @Synchronized fun search(query: String): List<Item> {
        val q = query.trim().lowercase()
        return all().filter { q.isEmpty() || it.text.lowercase().contains(q) || it.category == q }
    }

    /** Motivo por el que un texto no debe guardarse, o null si es aceptable. */
    fun sensitiveReason(text: String): String? = SensitiveGuard.reason(text)

    private fun validate(text: String): String? = when {
        text.isEmpty() -> "El recuerdo está vacío."
        text.length > MAX_TEXT -> "El recuerdo es demasiado largo (máx. $MAX_TEXT caracteres)."
        else -> sensitiveReason(text)?.let { "No guardo datos sensibles: $it." }
    }

    private fun clean(text: String) = text.trim().replace(Regex("\\s+"), " ")

    @Synchronized
    fun add(category: String, text: String): AddResult {
        val t = clean(text)
        validate(t)?.let { return AddResult(null, it) }
        items.firstOrNull { it.text.equals(t, ignoreCase = true) }?.let { return AddResult(it, null) }
        if (items.size >= MAX_ITEMS) return AddResult(null, "La memoria está llena ($MAX_ITEMS). Borra algunos recuerdos.")
        val cat = category.lowercase().takeIf { it in CATEGORIES } ?: "dato"
        var id: String
        do { id = UUID.randomUUID().toString().take(6) } while (items.any { it.id == id })
        val item = Item(id, cat, t, System.currentTimeMillis())
        items.add(item)
        save()
        return AddResult(item, null)
    }

    /** Devuelve un mensaje de error o null si se actualizó. */
    @Synchronized
    fun update(id: String, text: String): String? {
        val t = clean(text)
        validate(t)?.let { return it }
        val i = items.indexOfFirst { it.id == id }
        if (i < 0) return "Ese recuerdo ya no existe."
        items[i] = items[i].copy(text = t)
        save()
        return null
    }

    @Synchronized
    fun remove(id: String): Boolean {
        val removed = items.removeAll { it.id == id }
        if (removed) save()
        return removed
    }

    @Synchronized
    fun clear() { items.clear(); save() }
}
