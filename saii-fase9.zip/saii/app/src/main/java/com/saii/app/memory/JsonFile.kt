package com.saii.app.memory

import org.json.JSONArray
import java.io.File

/** SAII_Storage. Lectura y escritura atómica de arreglos JSON en el almacenamiento privado de la app. */
internal object JsonFile {
    fun read(f: File): JSONArray? {
        if (!f.exists()) return null
        return try {
            JSONArray(f.readText())
        } catch (e: Exception) {
            // Archivo dañado: se conserva una copia y se empieza limpio.
            f.renameTo(File(f.parentFile, f.nameWithoutExtension + ".corrupt." + System.currentTimeMillis() + ".json"))
            null
        }
    }

    fun write(f: File, a: JSONArray) {
        f.parentFile?.mkdirs()
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(a.toString())
        if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
    }
}
