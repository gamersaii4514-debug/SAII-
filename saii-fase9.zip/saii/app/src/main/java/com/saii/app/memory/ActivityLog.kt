package com.saii.app.memory

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** SAII_Storage. Historial de las acciones que SAII ejecutó (últimas 200), solo en el teléfono. */
object ActivityLog {
    data class Entry(val ts: Long, val tool: String, val args: String, val result: String, val error: Boolean)

    private const val MAX = 200
    private val items = ArrayDeque<Entry>()
    private var file: File? = null
    private var loaded = false
    private val _version = MutableStateFlow(0)
    val version: StateFlow<Int> = _version.asStateFlow()

    @Synchronized
    fun init(ctx: Context) {
        if (loaded) return
        val f = File(ctx.applicationContext.filesDir, "saii/activity.json")
        file = f
        try {
            JsonFile.read(f)?.let { arr ->
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    items.addLast(Entry(o.getLong("ts"), o.getString("tool"), o.getString("args"), o.getString("result"), o.getBoolean("error")))
                }
            }
        } catch (e: Exception) {
            items.clear()
        }
        loaded = true
    }

    private fun save() {
        val f = file ?: return
        val arr = JSONArray()
        items.forEach { arr.put(JSONObject().put("ts", it.ts).put("tool", it.tool).put("args", it.args).put("result", it.result).put("error", it.error)) }
        JsonFile.write(f, arr)
        _version.value++
    }

    @Synchronized
    fun add(e: Entry) {
        items.addFirst(e)
        while (items.size > MAX) items.removeLast()
        save()
    }

    @Synchronized fun all(): List<Entry> = items.toList()

    @Synchronized fun clear() { items.clear(); save() }
}
