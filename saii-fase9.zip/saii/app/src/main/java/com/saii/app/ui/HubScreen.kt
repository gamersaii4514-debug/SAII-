package com.saii.app.ui

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.saii.app.shortcuts.ShortcutInstaller

/** Sección del Hub. phase = 0 → ya disponible; >0 → se implementa en esa fase. */
private data class Section(val name: String, val phase: Int, val target: Screen? = null)

private val sections = listOf(
    Section("Conversaciones", 0, Screen.CHAT),
    Section("Administrador de permisos", 0, Screen.PERMISSIONS),
    Section("Cerebro de IA", 0, Screen.BRAIN),
    Section("Sistema de voz", 0, Screen.CHAT),
    Section("Activación por voz", 0, Screen.ACTIVATION),
    Section("Memoria", 0, Screen.MEMORY),
    Section("Herramientas del teléfono", 0, Screen.CHAT),
    Section("Aplicaciones conectadas", 0, Screen.INTEGRATIONS),
    Section("Automatizaciones", 0, Screen.AUTOMATIONS),
    Section("Panel de dispositivos inteligentes", 0, Screen.INTEGRATIONS),
    Section("Archivos de SAII", 0, Screen.DATA),
    Section("Historial de actividades", 0, Screen.ACTIVITY),
    Section("Configuraciones", 0, Screen.SETTINGS),
)

@Composable
fun HubScreen(onOpen: (Screen) -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("SAII", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
        Text("Sistema de Asistencia e Inteligencia Integral", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))

        OutlinedButton(onClick = {
            val ok = ShortcutInstaller.requestPin(ctx)
            Toast.makeText(
                ctx,
                if (ok) "Confirma en el launcher para fijar SAII en la pantalla principal"
                else "Tu launcher no permite fijar accesos directos. Usa el icono de SAII del cajón de aplicaciones.",
                Toast.LENGTH_LONG,
            ).show()
        }) { Text("Fijar SAII en la pantalla principal") }

        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(sections) { s ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth().height(96.dp).clickable {
                        if (s.target != null) onOpen(s.target)
                        else Toast.makeText(ctx, "${s.name}: disponible en la Fase ${s.phase}", Toast.LENGTH_SHORT).show()
                    },
                ) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
                        Text(s.name, style = MaterialTheme.typography.titleSmall)
                        Text(
                            if (s.phase == 0) "Disponible" else "Fase ${s.phase}",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (s.phase == 0) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                        )
                    }
                }
            }
        }
    }
}
