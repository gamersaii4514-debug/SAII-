package com.saii.app.phone

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.view.KeyEvent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.saii.app.R
import com.saii.app.activation.WakeService
import com.saii.app.activation.WakeWord
import com.saii.app.ai.Confirmer
import com.saii.app.ai.ToolHost
import com.saii.app.ai.ToolResult
import com.saii.app.core.SaiiState
import com.saii.app.memory.ActivityLog
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

/**
 * SAII_Android. Acciones reales del teléfono que el cerebro puede pedir.
 *
 * Reglas de seguridad aplicadas AQUÍ (no se delegan en el modelo):
 *  - llamadas y SMS exigen confirmación explícita del usuario y, ante cualquier duda, no se ejecutan;
 *  - cada acción usa solo el permiso que Android ya concedió; si falta, se informa en vez de intentar saltarlo;
 *  - los resultados describen lo que realmente ocurrió, incluidas las cosas que no se pueden verificar.
 */
class PhoneTools(
    private val ctx: Context,
    private val confirmer: Confirmer,
    private val onState: (SaiiState) -> Unit = {},
) : ToolHost {

    // ---------- Definición de herramientas ----------

    private fun str(d: String) = JSONObject().put("type", "string").put("description", d)
    private fun num(d: String) = JSONObject().put("type", "number").put("description", d)
    private fun bool(d: String) = JSONObject().put("type", "boolean").put("description", d)
    private fun choice(d: String, vararg v: String) =
        JSONObject().put("type", "string").put("description", d).put("enum", JSONArray(v.toList()))

    private fun spec(
        name: String, description: String,
        props: List<Pair<String, JSONObject>> = emptyList(), required: List<String> = emptyList(),
    ): JSONObject {
        val p = JSONObject().also { o -> props.forEach { (k, v) -> o.put(k, v) } }
        return JSONObject().put("name", name).put("description", description).put(
            "input_schema",
            JSONObject().put("type", "object").put("properties", p).put("required", JSONArray(required)),
        )
    }

    override fun specs(): JSONArray = JSONArray().apply {
        put(spec("get_datetime", "Fecha y hora locales actuales del teléfono."))
        put(spec("flashlight", "Enciende o apaga la linterna.", listOf("on" to bool("true enciende, false apaga")), listOf("on")))
        put(spec(
            "set_volume", "Cambia el volumen. Usa percent con action=set.",
            listOf(
                "action" to choice("set, up, down o mute", "set", "up", "down", "mute"),
                "percent" to num("Volumen 0-100 (solo con action=set)"),
                "stream" to choice("music (multimedia, por defecto), ring (timbre) o alarm", "music", "ring", "alarm"),
            ), listOf("action"),
        ))
        put(spec("set_brightness", "Fija el brillo de la pantalla (0-100).", listOf("percent" to num("Brillo 0-100")), listOf("percent")))
        put(spec("get_battery", "Nivel de batería y si está cargando."))
        put(spec(
            "set_alarm", "Crea una alarma en la app de reloj.",
            listOf("hour" to num("Hora 0-23"), "minute" to num("Minuto 0-59"), "label" to str("Nombre opcional")),
            listOf("hour", "minute"),
        ))
        put(spec(
            "set_timer", "Inicia un temporizador.",
            listOf("seconds" to num("Duración en segundos"), "label" to str("Nombre opcional")), listOf("seconds"),
        ))
        put(spec("open_app", "Abre una aplicación instalada por su nombre.", listOf("name" to str("Nombre de la app, p. ej. WhatsApp")), listOf("name")))
        put(spec("find_contact", "Busca contactos por nombre y devuelve sus números.", listOf("name" to str("Nombre o parte")), listOf("name")))
        put(spec(
            "call_phone", "Llama por teléfono (el usuario debe confirmar). Da name O number.",
            listOf("name" to str("Nombre del contacto"), "number" to str("Número de teléfono")),
        ))
        put(spec(
            "send_sms", "Envía un SMS (el usuario debe confirmar). Da name O number, y el texto.",
            listOf("name" to str("Nombre del contacto"), "number" to str("Número de teléfono"), "message" to str("Texto del SMS")),
            listOf("message"),
        ))
        put(spec(
            "media_control", "Controla la reproducción de la app multimedia activa.",
            listOf("action" to choice("play, pause, next o previous", "play", "pause", "next", "previous")), listOf("action"),
        ))
        put(spec("open_photos", "Abre la galería de fotos."))
        put(spec(
            "open_settings", "Abre una pantalla de ajustes (Wi-Fi, Bluetooth, etc.). Android no permite activarlos desde una app.",
            listOf("section" to choice("Sección", "wifi", "bluetooth", "display", "sound", "battery", "general")), listOf("section"),
        ))
        integ.specs().forEach { put(it) }   // Fase 7: integraciones
        auto.specs().forEach { put(it) }    // Fase 8: memoria y rutinas
    }

    private val integ = IntegrationTools(ctx, this)
    private val auto = AutomationTools(ctx, this)

    /** Herramientas que una rutina puede usar: todas menos las de memoria y rutinas (evita recursión). */
    internal fun routineToolNames(): Set<String> {
        val s = specs()
        return (0 until s.length()).map { s.getJSONObject(it).getString("name") }.toSet() - AutomationTools.NAMES
    }

    // ---------- Ejecución ----------

    override suspend fun run(name: String, input: JSONObject): ToolResult {
        onState(SaiiState.EXECUTING)
        try {
            return execute(name, input)
        } finally {
            onState(SaiiState.THINKING)
        }
    }

    /** Ejecuta una herramienta, la registra en el historial de actividades y nunca lanza (salvo cancelación). */
    internal suspend fun execute(name: String, input: JSONObject): ToolResult {
        val result = try {
            withContext(Dispatchers.Default) { dispatch(name, input) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: SecurityException) {
            ToolResult("Android negó el permiso necesario para esta acción (${e.message}).", true)
        } catch (e: Exception) {
            ToolResult("La acción falló: ${e.message ?: e.javaClass.simpleName}.", true)
        }
        runCatching {
            ActivityLog.init(ctx)
            // Los textos de mensajes y correos no se guardan en el historial.
            val shown = JSONObject(input.toString()).also { listOf("message", "body").forEach { k -> it.remove(k) } }
            ActivityLog.add(ActivityLog.Entry(System.currentTimeMillis(), name, shown.toString().take(140), result.text.take(200), result.isError))
        }
        return result
    }

    private suspend fun dispatch(name: String, a: JSONObject): ToolResult = when (name) {
        "get_datetime" -> ToolResult(
            ZonedDateTime.now().format(DateTimeFormatter.ofPattern("EEEE d 'de' MMMM 'de' yyyy, HH:mm", Locale("es")))
        )
        "flashlight" -> flashlight(a.optBoolean("on", true))
        "set_volume" -> volume(a)
        "set_brightness" -> brightness(a.optInt("percent", -1))
        "get_battery" -> battery()
        "set_alarm" -> alarm(a)
        "set_timer" -> timer(a)
        "open_app" -> openApp(a.optString("name"))
        "find_contact" -> findContact(a.optString("name"))
        "call_phone" -> call(a)
        "send_sms" -> sms(a)
        "media_control" -> media(a.optString("action"))
        "open_photos" -> openPhotos()
        "open_settings" -> openSettings(a.optString("section"))
        else -> integ.dispatch(name, a) ?: auto.dispatch(name, a) ?: ToolResult("Herramienta desconocida: $name", true)
    }

    internal fun missing(perm: String, human: String): ToolResult? =
        if (ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED) null
        else ToolResult("Falta el permiso de $human. El usuario debe autorizarlo en SAII › Permisos; no se hizo nada.", true)

    // ---- Linterna, volumen, brillo, batería ----

    private fun flashlight(on: Boolean): ToolResult {
        val cm = ctx.getSystemService(CameraManager::class.java)
        fun hasFlash(id: String) = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        val id = cm.cameraIdList.firstOrNull {
            hasFlash(it) && cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        } ?: cm.cameraIdList.firstOrNull { hasFlash(it) }
            ?: return ToolResult("Este teléfono no tiene linterna.", true)
        cm.setTorchMode(id, on)
        return ToolResult(if (on) "Linterna encendida." else "Linterna apagada.")
    }

    private fun volume(a: JSONObject): ToolResult {
        val am = ctx.getSystemService(AudioManager::class.java)
        val (stream, label) = when (a.optString("stream", "music")) {
            "ring" -> AudioManager.STREAM_RING to "timbre"
            "alarm" -> AudioManager.STREAM_ALARM to "alarma"
            else -> AudioManager.STREAM_MUSIC to "multimedia"
        }
        val max = am.getStreamMaxVolume(stream)
        when (a.optString("action", "set")) {
            "up" -> am.adjustStreamVolume(stream, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "down" -> am.adjustStreamVolume(stream, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "mute" -> am.setStreamVolume(stream, 0, AudioManager.FLAG_SHOW_UI)
            else -> {
                if (!a.has("percent")) return ToolResult("Falta el porcentaje de volumen.", true)
                val p = a.getInt("percent").coerceIn(0, 100)
                am.setStreamVolume(stream, (p * max / 100.0).roundToInt(), AudioManager.FLAG_SHOW_UI)
            }
        }
        return ToolResult("Volumen de $label ahora al ${am.getStreamVolume(stream) * 100 / max}%.")
    }

    private fun brightness(percent: Int): ToolResult {
        if (percent !in 0..100) return ToolResult("El brillo debe estar entre 0 y 100.", true)
        if (!Settings.System.canWrite(ctx)) {
            return ToolResult("Falta el permiso «Modificar ajustes del sistema». El usuario debe autorizarlo en SAII › Permisos; no se cambió el brillo.", true)
        }
        val cr = ctx.contentResolver
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, maxOf(1, percent * 255 / 100))
        return ToolResult("Brillo fijado al $percent% (modo manual).")
    }

    private fun battery(): ToolResult {
        val bm = ctx.getSystemService(BatteryManager::class.java)
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val st = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val status = st?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        return ToolResult("Batería al $pct%, ${if (charging) "cargando" else "sin cargar"}.")
    }

    // ---- Alarmas, temporizadores, apps, ajustes (abren pantallas: ver launch) ----

    private fun alarm(a: JSONObject): ToolResult {
        val h = a.optInt("hour", -1); val m = a.optInt("minute", -1)
        if (h !in 0..23 || m !in 0..59) return ToolResult("Hora no válida.", true)
        val label = a.optString("label")
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val hhmm = "%02d:%02d".format(h, m)
        return launch(i, "Crear alarma $hhmm", "Pedí a la app de reloj crear la alarma de las $hhmm (no puedo verificar que la haya guardado).")
    }

    private fun timer(a: JSONObject): ToolResult {
        val s = a.optInt("seconds", -1)
        if (s !in 1..86_400) return ToolResult("Duración no válida (1 s a 24 h).", true)
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, s).putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label"))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return launch(i, "Iniciar temporizador de $s s", "Pedí a la app de reloj iniciar el temporizador de $s segundos (no puedo verificar que haya arrancado).")
    }

    private fun openApp(name: String): ToolResult {
        val q = WakeWord.normalize(name)
        if (q.isEmpty()) return ToolResult("Falta el nombre de la app.", true)
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
        val scored = apps.mapNotNull { (pkg, label) ->
            val n = WakeWord.normalize(label)
            val score = when { n == q -> 0; n.startsWith(q) -> 1; n.contains(q) -> 2; else -> return@mapNotNull null }
            Triple(pkg, label, score * 1000 + n.length)
        }.sortedBy { it.third }
        val best = scored.firstOrNull() ?: return ToolResult("No encontré una app llamada «$name» en este teléfono.", true)
        val intent = pm.getLaunchIntentForPackage(best.first) ?: return ToolResult("No se pudo abrir ${best.second}.", true)
        return launch(intent, "Abrir ${best.second}", "Abriendo ${best.second}.")
    }

    private fun openPhotos(): ToolResult {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_GALLERY)
        return launchWithFallback(
            i, Intent(Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI),
            "Abrir fotos", "Abriendo la galería de fotos.",
        )
    }

    private fun openSettings(section: String): ToolResult {
        val action = when (section) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return launch(Intent(action), "Abrir ajustes ($section)", "Abrí la pantalla de ajustes ($section). El usuario debe cambiarlo allí: Android no permite que una app lo active.")
    }

    // ---- Contactos, llamadas y SMS ----

    internal data class Match(val name: String, val number: String)

    private fun allContacts(): List<Match> {
        val out = mutableListOf<Match>()
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null,
        )?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0) ?: continue
                val num = c.getString(1) ?: continue
                out.add(Match(n, num))
            }
        }
        return out
    }

    private fun digits(s: String) = s.filter { it.isDigit() }

    private fun search(query: String): List<Match> {
        val nq = WakeWord.normalize(query)
        if (nq.isEmpty()) return emptyList()
        val all = allContacts()
        val exact = all.filter { WakeWord.normalize(it.name) == nq }
        val pool = exact.ifEmpty {
            val toks = nq.split(" ")
            all.filter { c -> val n = WakeWord.normalize(c.name); n.contains(nq) || toks.all { it in n } }
        }
        return pool.distinctBy { digits(it.number) }.take(8)
    }

    private fun findContact(name: String): ToolResult {
        missing(Manifest.permission.READ_CONTACTS, "contactos")?.let { return it }
        val r = search(name)
        return if (r.isEmpty()) ToolResult("No hay contactos que coincidan con «$name».")
        else ToolResult("Contactos encontrados: " + r.joinToString("; ") { "${it.name} (${it.number})" })
    }

    internal sealed interface Target {
        data class Ok(val m: Match) : Target
        data class Fail(val r: ToolResult) : Target
    }

    internal fun resolve(a: JSONObject): Target {
        val number = a.optString("number").trim()
        if (number.isNotEmpty()) {
            if (digits(number).length < 3) return Target.Fail(ToolResult("El número no es válido.", true))
            return Target.Ok(Match(number, number))
        }
        val name = a.optString("name").trim()
        if (name.isEmpty()) return Target.Fail(ToolResult("Falta el nombre o el número.", true))
        missing(Manifest.permission.READ_CONTACTS, "contactos")?.let { return Target.Fail(it) }
        val r = search(name)
        return when {
            r.isEmpty() -> Target.Fail(ToolResult("No encontré a «$name» en los contactos. Pide al usuario el nombre exacto o el número.", true))
            r.size > 1 -> Target.Fail(ToolResult(
                "Hay varios resultados: " + r.joinToString("; ") { "${it.name} (${it.number})" } +
                    ". Pregunta al usuario a cuál se refiere.", true,
            ))
            else -> Target.Ok(r[0])
        }
    }

    internal suspend fun confirm(summary: String): Boolean = withContext(Dispatchers.Main) { confirmer.confirm(summary) }

    private suspend fun call(a: JSONObject): ToolResult {
        missing(Manifest.permission.CALL_PHONE, "llamadas")?.let { return it }
        val t = when (val x = resolve(a)) { is Target.Fail -> return x.r; is Target.Ok -> x.m }
        if (!confirm("Llamar a ${t.name} (${t.number})")) return ToolResult("El usuario NO confirmó. No se hizo la llamada.")
        ctx.getSystemService(TelecomManager::class.java).placeCall(Uri.fromParts("tel", t.number, null), Bundle())
        return ToolResult("Llamada iniciada a ${t.name}.")
    }

    private suspend fun sms(a: JSONObject): ToolResult {
        missing(Manifest.permission.SEND_SMS, "SMS")?.let { return it }
        val msg = a.optString("message").trim()
        if (msg.isEmpty()) return ToolResult("Falta el texto del mensaje.", true)
        if (msg.length > 1000) return ToolResult("El mensaje es demasiado largo (máx. 1000 caracteres).", true)
        val t = when (val x = resolve(a)) { is Target.Fail -> return x.r; is Target.Ok -> x.m }
        if (!confirm("Enviar SMS a ${t.name} (${t.number}): «$msg»")) return ToolResult("El usuario NO confirmó. No se envió el SMS.")
        @Suppress("DEPRECATION")
        val sms = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
        val parts = sms.divideMessage(msg)
        if (parts.size > 1) sms.sendMultipartTextMessage(t.number, null, parts, null, null)
        else sms.sendTextMessage(t.number, null, msg, null, null)
        return ToolResult("SMS entregado al sistema para enviarse a ${t.name}. No puedo confirmar que haya llegado.")
    }

    // ---- Multimedia ----

    private fun media(action: String): ToolResult {
        val code = when (action) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> return ToolResult("Acción multimedia no válida.", true)
        }
        val am = ctx.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return ToolResult("Orden «$action» enviada al reproductor activo. Si no había ninguno abierto, no ocurre nada; no puedo verificarlo.")
    }

    // ---------- Abrir pantallas ----------
    // Android bloquea que una app en segundo plano abra pantallas por su cuenta. Con SAII visible se abre
    // directamente; en segundo plano se deja una notificación que el usuario toca para completar la acción.

    private fun launch(intent: Intent, label: String, okText: String): ToolResult =
        launchWithFallback(intent, null, label, okText)

    internal fun launchWithFallback(primary: Intent, fallback: Intent?, label: String, okText: String): ToolResult {
        if (WakeService.isUiVisible) {
            for (candidate in listOfNotNull(primary, fallback)) {
                try {
                    ctx.startActivity(candidate.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    return ToolResult(okText)
                } catch (_: ActivityNotFoundException) { /* prueba la alternativa */ }
            }
            return ToolResult("No hay ninguna app en este teléfono que pueda hacerlo.", true)
        }
        return notifyToTap(primary.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), fallback?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), label)
    }

    private fun notifyToTap(primary: Intent, fallback: Intent?, label: String): ToolResult {
        val pm = ctx.packageManager
        val usable = if (primary.resolveActivity(pm) != null || primary.`package` != null) primary else fallback ?: primary
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ACTION_CHANNEL, "Acciones de SAII", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(ctx, label.hashCode(), usable, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, ACTION_CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_saii)
            .setContentTitle("SAII: $label")
            .setContentText("Toca para completarlo")
            .setContentIntent(pi).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        val allowed = NotificationManagerCompat.from(ctx).areNotificationsEnabled()
        if (allowed) NotificationManagerCompat.from(ctx).notify(label.hashCode(), n)
        return if (allowed) ToolResult(
            "SAII está en segundo plano y Android no permite abrir pantallas desde aquí. Dejé una notificación «$label»: " +
                "el usuario debe tocarla para completarlo. Todavía NO está hecho.", true,
        ) else ToolResult(
            "No se pudo hacer: SAII está en segundo plano (Android bloquea abrir pantallas) y las notificaciones de SAII están desactivadas.", true,
        )
    }

    private companion object {
        const val ACTION_CHANNEL = "saii_actions"
    }
}
