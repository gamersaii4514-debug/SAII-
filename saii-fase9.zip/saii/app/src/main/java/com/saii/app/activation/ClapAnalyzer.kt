package com.saii.app.activation

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * SAII_ClapDetector. Lógica pura (sin Android) que decide si hay DOS aplausos a partir de tramas de audio de 20 ms.
 * El tiempo avanza con las muestras recibidas, así que es determinista y se puede probar con audio sintético.
 *
 * Un aplauso es un golpe breve: sube bruscamente por encima del ruido ambiente y decae en menos de ~160 ms.
 * Se descartan: sonidos sostenidos (voz, música, motores), un solo golpe, golpes demasiado juntos (eco),
 * demasiado separados, y tres o más golpes seguidos (aplausos de público, ritmo).
 *
 * @param sensitivity 0..100 (más alto = detecta aplausos más suaves)
 * @param maxGapMs máximo tiempo entre el inicio del primer y del segundo aplauso
 */
class ClapAnalyzer(
    sensitivity: Int,
    maxGapMs: Int,
    private val minGapMs: Int = 150,
    private val frameMs: Int = 20,
) {
    private val sens = sensitivity.coerceIn(0, 100)
    private val maxGap = maxGapMs.coerceIn(300, 1200)
    private val ratio = 12.0 - sens * 0.08          // cuántas veces el ruido ambiente
    private val absMin = 0.08 - sens * 0.0006        // umbral absoluto mínimo (0..1 de escala completa)

    private enum class S { IDLE, EVENT, SUSTAINED, COOLDOWN }

    private var s = S.IDLE
    private var t = 0L
    private var warm = 0
    private var noise = 0.005
    private val prev = DoubleArray(3)
    private var eventStart = 0L
    private var eventFrames = 0
    private var quietRun = 0
    private var cooldownUntil = 0L
    private var blockedUntil = 0L
    private var firstT = -1L
    private var secondT = -1L

    /** Nivel RMS (0..1) de la última trama, para indicadores. */
    var lastLevel = 0.0
        private set

    /** Devuelve true en el momento en que se confirma un doble aplauso. */
    fun process(buf: ShortArray, n: Int): Boolean {
        if (n <= 0) return false
        var sum = 0.0
        for (i in 0 until n) { val x = buf[i] / 32768.0; sum += x * x }
        val rms = sqrt(sum / n)
        lastLevel = rms
        t += frameMs

        // Calibración inicial del ruido ambiente (0,5 s)
        if (warm < 25) {
            warm++
            noise = if (warm == 1) rms else noise + (rms - noise) / warm
            noise = max(noise, 0.002)
            pushPrev(rms)
            return false
        }

        val thr = max(noise * ratio, absMin)
        val prevMax = max(prev[0], max(prev[1], prev[2]))

        when (s) {
            S.IDLE -> {
                if (rms > thr && rms > 2.5 * prevMax) {
                    s = S.EVENT; eventStart = t; eventFrames = 1
                } else {
                    noise += 0.02 * (min(rms, noise * 3) - noise)
                    noise = max(noise, 0.002)
                }
            }
            S.EVENT -> {
                eventFrames++
                if (rms < thr * 0.5) {
                    if (eventFrames * frameMs <= MAX_CLAP_MS) onClap(eventStart)
                    s = S.COOLDOWN; cooldownUntil = t + 80
                } else if (eventFrames * frameMs > MAX_CLAP_MS) {
                    resetClaps(); s = S.SUSTAINED; quietRun = 0   // voz, música o motor: no es un aplauso
                }
            }
            S.SUSTAINED -> {
                noise += 0.05 * (rms - noise)                       // el ambiente cambió: adaptarse
                noise = max(noise, 0.002)
                if (rms < thr * 0.5) quietRun++ else quietRun = 0
                if (quietRun >= 5) { s = S.COOLDOWN; cooldownUntil = t + 100 }
            }
            S.COOLDOWN -> if (t >= cooldownUntil) s = S.IDLE
        }
        pushPrev(rms)

        // Confirmación: segundo aplauso y 500 ms sin un tercero
        if (secondT >= 0 && t - secondT >= CONFIRM_MS && s != S.EVENT) {
            resetClaps()
            return true
        }
        return false
    }

    private fun onClap(start: Long) {
        if (t < blockedUntil) return
        if (secondT >= 0) {                  // tercer golpe: aplausos de público o ritmo
            resetClaps(); blockedUntil = t + 1500; return
        }
        if (firstT < 0) { firstT = start; return }
        val gap = start - firstT
        when {
            gap < minGapMs -> {}             // eco del mismo golpe
            gap <= maxGap -> secondT = start
            else -> firstT = start           // demasiado separado: este pasa a ser el primero
        }
    }

    private fun resetClaps() { firstT = -1; secondT = -1 }

    private fun pushPrev(rms: Double) { prev[0] = prev[1]; prev[1] = prev[2]; prev[2] = rms }

    private companion object {
        const val MAX_CLAP_MS = 160
        const val CONFIRM_MS = 500
    }
}
