package com.saii.app.memory

/** SAII_Security. Decide si un texto contiene datos que SAII nunca debe guardar en su memoria. */
object SensitiveGuard {
    private val longNumber = Regex("""\d(?:[ -]?\d){12,}""")      // 13+ dígitos: tarjetas, cuentas
    private val secretWords = Regex("""\b(pin|cvv|token)\b""")

    /** Motivo por el que NO debe guardarse, o null si es aceptable. */
    fun reason(text: String): String? {
        if (longNumber.containsMatchIn(text)) return "parece un número de tarjeta o de cuenta"
        val t = text.lowercase()
        if (listOf("contraseña", "contrasena", "password").any { t.contains(it) } || secretWords.containsMatchIn(t)) {
            return "parece una contraseña o clave"
        }
        return null
    }
}
