package com.saii.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.saii.app.core.SaiiViewModel

/** Ajustes generales: reúne interruptores ya existentes y atajos a pantallas del sistema. Nada simulado. */
@Composable
fun SettingsScreen(vm: SaiiViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val speak by vm.speakReplies.collectAsState()
    val continuous by vm.continuous.collectAsState()
    val prefs = remember { ctx.getSharedPreferences("saii_settings", Context.MODE_PRIVATE) }
    var web by remember { mutableStateOf(prefs.getBoolean("websearch", true)) }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ Hub") }
            Text("Configuraciones", style = MaterialTheme.typography.titleLarge)
        }
        Spacer(Modifier.height(8.dp))

        SettingRow("Responder en voz", "SAII lee sus respuestas en voz alta.", speak) { vm.setSpeakReplies(it) }
        SettingRow("Conversación continua", "Tras responder por voz, vuelve a escuchar.", continuous) { vm.setContinuous(it) }
        SettingRow("Búsqueda web", "Permite a SAII consultar Internet (se factura en tu cuenta de Anthropic).", web) {
            web = it; vm.setWebSearch(it)
        }

        Spacer(Modifier.height(16.dp))
        Text("Ajustes del sistema", style = MaterialTheme.typography.titleMedium)
        Text(
            "Estas opciones las controla Android; SAII solo abre la pantalla correspondiente.",
            style = MaterialTheme.typography.bodySmall,
        )
        Spacer(Modifier.height(8.dp))
        OpenButton(ctx, "Información de la app (permisos, batería)") {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
        }
        OpenButton(ctx, "Optimización de batería") { Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) }
        OpenButton(ctx, "Texto a voz (voz en español)") { Intent("com.android.settings.TTS_SETTINGS") }
        OpenButton(ctx, "Idioma y entrada de voz") { Intent(Settings.ACTION_VOICE_INPUT_SETTINGS) }

        Spacer(Modifier.height(16.dp))
        Text("SAII · Fase 9", style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun SettingRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(sub, style = MaterialTheme.typography.bodySmall)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun OpenButton(ctx: Context, label: String, intent: () -> Intent) {
    OutlinedButton(
        onClick = {
            try {
                ctx.startActivity(intent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                Toast.makeText(ctx, "Este teléfono no tiene esa pantalla de ajustes.", Toast.LENGTH_LONG).show()
            }
        },
        modifier = Modifier.fillMaxWidth(),
    ) { Text(label) }
}
