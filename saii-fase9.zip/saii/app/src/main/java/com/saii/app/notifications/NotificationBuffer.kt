package com.saii.app.notifications

/**
 * SAII_Notifications. Memoria TEMPORAL (solo RAM, máx. 50) de las últimas notificaciones recibidas
 * mientras el usuario mantenga activado el acceso a notificaciones. No se guarda en disco.
 */
object NotificationBuffer {
    data class Entry(val app: String, val title: String, val text: String, val time: Long)

    private val items = ArrayDeque<Entry>()
    @Volatile var connected = false

    @Synchronized fun add(e: Entry) {
        items.addFirst(e)
        while (items.size > 50) items.removeLast()
    }

    @Synchronized fun recent(limit: Int, appFilter: String?): List<Entry> {
        val f = appFilter?.lowercase()?.takeIf { it.isNotBlank() }
        return items.filter { f == null || it.app.lowercase().contains(f) }.take(limit)
    }

    @Synchronized fun clear() = items.clear()
}
