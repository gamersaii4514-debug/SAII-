package com.saii.app.phone

import com.saii.app.activation.WakeWord

data class LocalCommand(val tool: String, val args: Map<String, Any> = emptyMap())

/**
 * SAII_Core. Modo limitado SIN conexión: reconoce órdenes simples del teléfono con reglas locales
 * (sin modelo de IA) y devuelve la herramienta a ejecutar. Lo que no reconoce devuelve null: no se adivina.
 */
object OfflineCommands {
    const val HELP = "Sin conexión a Internet solo puedo ejecutar órdenes simples del teléfono: linterna, volumen, brillo, " +
        "batería, hora, abrir aplicaciones, temporizador y alarma."

    private val on = setOf("enciende", "prende", "activa", "enciendela", "prendela", "activala", "pon", "ponla")
    private val off = setOf("apaga", "desactiva", "apagala", "desactivala", "quita")
    private val openVerbs = setOf("abre", "abrir", "abra", "lanza", "ejecuta", "inicia")
    private val skipWords = setOf("la", "el", "los", "las", "aplicacion", "app", "de", "mi", "mis", "un", "una")
    private val numberWords = mapOf(
        "un" to 1, "una" to 1, "uno" to 1, "dos" to 2, "tres" to 3, "cuatro" to 4, "cinco" to 5, "seis" to 6,
        "siete" to 7, "ocho" to 8, "nueve" to 9, "diez" to 10, "once" to 11, "doce" to 12, "quince" to 15,
        "veinte" to 20, "treinta" to 30,
    )

    fun parse(text: String): LocalCommand? {
        val base = if (WakeWord.matches(text)) WakeWord.stripWake(text) else text
        val n = WakeWord.normalize(base)
        if (n.isEmpty()) return null
        val tokens = n.split(" ")
        // «cinco minutos» → «5 minutos»
        val digits = tokens.joinToString(" ") { numberWords[it]?.toString() ?: it }

        // Linterna
        if ("linterna" in n || "flash" in tokens || "lampara" in n) {
            return when {
                tokens.any { it in off } -> LocalCommand("flashlight", mapOf("on" to false))
                tokens.any { it in on } -> LocalCommand("flashlight", mapOf("on" to true))
                else -> null
            }
        }

        // Temporizador
        if ("temporizador" in n || "timer" in tokens) {
            var seconds = 0
            if ("media hora" in n) seconds += 1800
            Regex("""(\d+) (horas?|minutos?|min|segundos?|seg)\b""").findAll(digits).forEach { m ->
                val v = m.groupValues[1].toIntOrNull() ?: return@forEach
                seconds += when {
                    m.groupValues[2].startsWith("hora") -> v * 3600
                    m.groupValues[2].startsWith("min") -> v * 60
                    else -> v
                }
            }
            return if (seconds in 1..86_400) LocalCommand("set_timer", mapOf("seconds" to seconds)) else null
        }

        // Alarma
        if ("alarma" in n) {
            val m = Regex("""\ba las? (\d{1,2})(?: (\d{2}))?""").find(digits) ?: return null
            var h = m.groupValues[1].toInt()
            var min = m.groupValues[2].takeIf { it.isNotEmpty() }?.toInt() ?: 0
            if ("y media" in digits) min = 30
            if ("y cuarto" in digits) min = 15
            if (("de la tarde" in n || "de la noche" in n) && h < 12) h += 12
            if (h !in 0..23 || min !in 0..59) return null
            return LocalCommand("set_alarm", mapOf("hour" to h, "minute" to min))
        }

        // Batería
        if ("bateria" in n) return LocalCommand("get_battery")

        // Hora y fecha
        if ("que hora es" in n || "dime la hora" in n || "que dia es" in n || "que fecha" in n || "fecha de hoy" in n) {
            return LocalCommand("get_datetime")
        }

        // Volumen
        if ("volumen" in n) {
            val pct = Regex("""\b(\d{1,3})\b""").find(digits)?.groupValues?.get(1)?.toIntOrNull()
            return when {
                tokens.any { it in setOf("sube", "subir", "aumenta", "aumentar") } || "mas alto" in n ->
                    LocalCommand("set_volume", mapOf("action" to "up"))
                tokens.any { it in setOf("baja", "bajar", "disminuye", "reduce") } || "mas bajo" in n ->
                    LocalCommand("set_volume", mapOf("action" to "down"))
                tokens.any { it in setOf("silencia", "mutea", "mute") } || "sin sonido" in n ->
                    LocalCommand("set_volume", mapOf("action" to "mute"))
                pct != null && pct in 0..100 -> LocalCommand("set_volume", mapOf("action" to "set", "percent" to pct))
                else -> null
            }
        }

        // Brillo
        if ("brillo" in n) {
            val pct = Regex("""\b(\d{1,3})\b""").find(digits)?.groupValues?.get(1)?.toIntOrNull()
            return when {
                pct != null && pct in 0..100 -> LocalCommand("set_brightness", mapOf("percent" to pct))
                "maximo" in n -> LocalCommand("set_brightness", mapOf("percent" to 100))
                "minimo" in n -> LocalCommand("set_brightness", mapOf("percent" to 1))
                else -> null
            }
        }

        // Fotos
        if (("fotos" in tokens || "fotografias" in tokens || "galeria" in tokens) &&
            tokens.any { it in openVerbs || it == "muestra" || it == "muestrame" }
        ) return LocalCommand("open_photos")

        // Abrir una aplicación
        if (tokens.first() in openVerbs) {
            val rest = tokens.drop(1).dropWhile { it in skipWords }
            if (rest.isEmpty() || rest.size > 4 || rest.any { it == "y" || it == "luego" || it == "despues" }) return null
            return LocalCommand("open_app", mapOf("name" to rest.joinToString(" ")))
        }
        return null
    }
}
