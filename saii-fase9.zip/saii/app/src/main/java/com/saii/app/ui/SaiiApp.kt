package com.saii.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.saii.app.core.SaiiViewModel

enum class Screen { HUB, CHAT, PERMISSIONS, BRAIN, ACTIVATION, INTEGRATIONS, MEMORY, ACTIVITY, AUTOMATIONS, DATA, SETTINGS }

private val Bg = Color(0xFF0B1220)
private val Accent = Color(0xFF38BDF8)

@Composable
fun SaiiTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, background = Bg, surface = Color(0xFF111B2E),
            onPrimary = Color(0xFF00212E), onSurface = Color(0xFFE6EEF8), onBackground = Color(0xFFE6EEF8),
            surfaceVariant = Color(0xFF1A2740),
        ),
        content = content,
    )
}

@Composable
fun SaiiApp(vm: SaiiViewModel, screen: MutableState<Screen>) {
    BackHandler(enabled = screen.value != Screen.HUB) { screen.value = Screen.HUB }
    val confirm by vm.pendingConfirm.collectAsStateWithLifecycle()
    confirm?.let { req ->
        AlertDialog(
            onDismissRequest = { vm.answerConfirm(false) },
            title = { Text("SAII necesita tu confirmación") },
            text = { Text(req.summary) },
            confirmButton = { TextButton(onClick = { vm.answerConfirm(true) }) { Text("Confirmar") } },
            dismissButton = { TextButton(onClick = { vm.answerConfirm(false) }) { Text("Cancelar") } },
        )
    }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Box(Modifier.systemBarsPadding()) {
            when (screen.value) {
                Screen.HUB -> HubScreen(onOpen = { screen.value = it })
                Screen.CHAT -> ChatScreen(vm = vm, onBack = { screen.value = Screen.HUB })
                Screen.PERMISSIONS -> PermissionsScreen(onBack = { screen.value = Screen.HUB })
                Screen.BRAIN -> BrainScreen(vm = vm, onBack = { screen.value = Screen.HUB })
                Screen.ACTIVATION -> ActivationScreen(onBack = { screen.value = Screen.HUB })
                Screen.INTEGRATIONS -> IntegrationsScreen(vm = vm, onBack = { screen.value = Screen.HUB })
                Screen.MEMORY -> MemoryScreen(onBack = { screen.value = Screen.HUB })
                Screen.ACTIVITY -> ActivityScreen(onBack = { screen.value = Screen.HUB })
                Screen.AUTOMATIONS -> AutomationsScreen(vm = vm, onBack = { screen.value = Screen.HUB })
                Screen.DATA -> DataScreen(vm = vm, onBack = { screen.value = Screen.HUB })
                Screen.SETTINGS -> SettingsScreen(vm = vm, onBack = { screen.value = Screen.HUB })
            }
        }
    }
}
