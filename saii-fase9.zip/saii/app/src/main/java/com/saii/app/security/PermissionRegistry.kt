package com.saii.app.security

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/** SAII_Security. Registro transparente de permisos: qué se pide, para qué y en qué fase se usará. */
data class PermissionEntry(
    val app: String,
    val permission: String,
    val enables: String,
    val phase: Int,
)

object PermissionRegistry {
    val entries: List<PermissionEntry> = buildList {
        add(PermissionEntry("Micrófono", Manifest.permission.RECORD_AUDIO, "Voz, «Hey SAII» y detector de aplausos", 3))
        add(PermissionEntry("Contactos", Manifest.permission.READ_CONTACTS, "Buscar a quién llamar o escribir", 6))
        add(PermissionEntry("Llamadas", Manifest.permission.CALL_PHONE, "Llamar (siempre con confirmación)", 6))
        add(PermissionEntry("SMS", Manifest.permission.SEND_SMS, "Enviar SMS (siempre con confirmación)", 6))
        add(PermissionEntry("Modificar ajustes del sistema", WRITE_SETTINGS_KEY, "Cambiar el brillo de la pantalla", 6))
        add(PermissionEntry("Calendario", Manifest.permission.READ_CALENDAR, "Leer tus próximos eventos", 7))
        add(PermissionEntry("Acceso a notificaciones", NOTIFICATION_LISTENER_KEY, "Leer notificaciones recientes cuando lo pidas (solo en memoria)", 7))
        if (Build.VERSION.SDK_INT >= 33) {
            add(PermissionEntry("Notificaciones", Manifest.permission.POST_NOTIFICATIONS, "Aviso del servicio en segundo plano", 4))
        }
    }

    /** Permiso especial (no se pide con diálogo): se concede en una pantalla de Ajustes. */
    const val WRITE_SETTINGS_KEY = "saii.WRITE_SETTINGS"
    const val NOTIFICATION_LISTENER_KEY = "saii.NOTIFICATION_LISTENER"

    fun isGranted(context: Context, e: PermissionEntry): Boolean = when (e.permission) {
        WRITE_SETTINGS_KEY -> Settings.System.canWrite(context)
        NOTIFICATION_LISTENER_KEY -> NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)
        else -> ContextCompat.checkSelfPermission(context, e.permission) == PackageManager.PERMISSION_GRANTED
    }

    /** Acciones sensibles que SIEMPRE exigen confirmación explícita del usuario. */
    val sensitiveActions = setOf("call", "sms", "send_message", "post", "purchase", "delete")
}
