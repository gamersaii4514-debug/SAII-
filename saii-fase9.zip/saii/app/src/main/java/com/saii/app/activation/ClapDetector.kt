package com.saii.app.activation

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * SAII_ClapDetector. Captura audio con AudioRecord (16 kHz, mono) y alimenta a [ClapAnalyzer].
 * Cuando confirma un doble aplauso libera el micrófono ANTES de avisar, para que el reconocedor
 * de voz pueda usarlo enseguida. Los callbacks se entregan en el hilo principal.
 * Es de un solo uso: tras un doble aplauso o un error hay que crear otro.
 */
class ClapDetector(
    private val sensitivity: Int,
    private val maxGapMs: Int,
    private val onDoubleClap: () -> Unit,
    private val onError: (String) -> Unit,
    private val onLevel: ((Float) -> Unit)? = null,
) {
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "saii-clap").also { it.start() }
    }

    fun stop() {
        running = false
        thread?.let { if (it !== Thread.currentThread()) it.join(500) }
        thread = null
    }

    private fun fail(msg: String) { running = false; main.post { onError(msg) } }

    @SuppressLint("MissingPermission")   // el permiso lo comprueba quien crea el detector
    private fun loop() {
        val rate = 16_000
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) { fail("Este teléfono no permite capturar audio."); return }

        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, max(minBuf, 8192),
            )
        } catch (e: Exception) { fail("No se pudo abrir el micrófono."); return }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release(); fail("No se pudo abrir el micrófono (permiso denegado o en uso)."); return
        }

        val analyzer = ClapAnalyzer(sensitivity, maxGapMs)
        val frame = ShortArray(rate / 50)   // 20 ms
        var fired = false
        var levelCount = 0
        try {
            rec.startRecording()
            if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                fail("El micrófono está en uso por otra aplicación."); return
            }
            while (running) {
                var read = 0
                while (read < frame.size && running) {
                    val r = rec.read(frame, read, frame.size - read)
                    if (r < 0) { fail("Se perdió el acceso al micrófono."); return }
                    read += r
                }
                if (!running) break
                if (analyzer.process(frame, read)) { fired = true; running = false }
                if (onLevel != null && ++levelCount % 3 == 0) {
                    val lv = min(1f, (sqrt(analyzer.lastLevel) * 1.5).toFloat())
                    main.post { onLevel.invoke(lv) }
                }
            }
        } catch (e: Exception) {                    // p. ej. startRecording() con el micrófono bloqueado
            fail("No se pudo usar el micrófono.")
        } finally {
            runCatching { rec.stop() }
            rec.release()
        }
        if (fired) main.post { onDoubleClap() }
    }
}
