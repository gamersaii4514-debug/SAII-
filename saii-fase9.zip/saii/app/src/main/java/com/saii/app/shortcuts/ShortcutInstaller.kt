package com.saii.app.shortcuts

import android.content.Context
import android.content.Intent
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.saii.app.MainActivity
import com.saii.app.R

object ShortcutInstaller {
    const val ACTION_CHAT = "com.saii.app.OPEN_CHAT"
    const val ACTION_HUB = "com.saii.app.OPEN_HUB"

    private fun hubShortcut(context: Context) = ShortcutInfoCompat.Builder(context, "saii_hub_pinned")
        .setShortLabel("SAII")
        .setLongLabel("Espacio SAII")
        .setIcon(IconCompat.createWithResource(context, R.mipmap.ic_launcher))
        .setIntent(Intent(context, MainActivity::class.java).setAction(ACTION_HUB))
        .build()

    /** Acceso directo dinámico (aparece al mantener pulsado el icono). */
    fun publishDynamic(context: Context) {
        val chat = ShortcutInfoCompat.Builder(context, "saii_chat_dyn")
            .setShortLabel("Hablar con SAII")
            .setIcon(IconCompat.createWithResource(context, R.mipmap.ic_launcher))
            .setIntent(Intent(context, MainActivity::class.java).setAction(ACTION_CHAT))
            .build()
        runCatching { ShortcutManagerCompat.setDynamicShortcuts(context, listOf(chat)) }
    }

    fun isPinSupported(context: Context) = ShortcutManagerCompat.isRequestPinShortcutSupported(context)

    /** Pide al launcher fijar el icono SAII en la pantalla principal. El usuario debe aceptar. */
    fun requestPin(context: Context): Boolean =
        isPinSupported(context) && ShortcutManagerCompat.requestPinShortcut(context, hubShortcut(context), null)
}
