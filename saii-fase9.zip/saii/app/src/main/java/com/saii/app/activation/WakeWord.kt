package com.saii.app.activation

import java.text.Normalizer

/**
 * SAII_Activation. Detección de «Hey SAII», «Oye SAII» y «SAII» sobre el texto que devuelve
 * el reconocedor de voz del sistema. Como el reconocedor no conoce la palabra «SAII», se aceptan
 * las transcripciones más habituales de ese sonido.
 */
object WakeWord {
    private val variants = setOf("saii", "sai", "sayi", "sahi", "saiy", "say", "say i", "sa i", "sai i")

    fun normalize(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    fun matches(text: String): Boolean {
        val n = normalize(text)
        if (n.isEmpty()) return false
        val tokens = n.split(" ")
        if (tokens.any { it in variants }) return true
        // «sai i», «sa ii»… partidos en dos palabras
        return n.replace(" ", "").contains("saii")
    }

    /** Quita «hey/oye SAII» y lo anterior; devuelve el resto (la orden) o vacío si solo dijo el nombre. */
    fun stripWake(text: String): String {
        val toks = normalize(text).split(" ").filter { it.isNotEmpty() }.toMutableList()
        val idx = toks.indexOfFirst { it in variants }
        if (idx < 0) return text
        var rest = toks.drop(idx + 1)
        if (rest.firstOrNull() in setOf("i", "ii")) rest = rest.drop(1)   // «say i» partido en dos palabras
        return rest.joinToString(" ")
    }

    private val yesWords = setOf("si", "claro", "confirmo", "confirmado", "dale", "adelante", "ok", "okay", "hazlo", "correcto", "afirmativo", "vale", "listo")
    private val noWords = setOf("no", "cancela", "cancelar", "detente", "para", "negativo", "nunca")

    /** true = sí, false = no, null = no se entendió. Ante la duda quien llama debe tratarlo como «no». */
    fun yesNo(text: String): Boolean? {
        val toks = normalize(text).split(" ").filter { it.isNotEmpty() }
        if (toks.isEmpty()) return null
        if (toks.any { it in noWords }) return false
        return if (toks.first() in yesWords) true else null
    }

    private val endWords = setOf(
        "nada", "gracias", "eso es todo", "es todo", "adios", "cancelar", "terminar", "ya esta", "nada mas"
    )

    /** Frases con las que el usuario da por terminada la conversación manos libres. */
    fun isEndPhrase(text: String): Boolean = normalize(text) in endWords
}
