package com.saii.app.activation

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.saii.app.MainActivity
import com.saii.app.R

/**
 * SAII_Activation. Tras reiniciar el teléfono Android NO permite arrancar un servicio de micrófono en segundo plano
 * (restricción del sistema desde Android 14/15). Por eso, si el usuario tenía la escucha activada, SAII deja una
 * notificación: con un toque se abre y se reactiva sola.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val wanted = context.getSharedPreferences("saii_settings", Context.MODE_PRIVATE).getBoolean("wake_enabled", false)
        if (!wanted) return

        context.getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Reactivar SAII", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_saii)
            .setContentTitle("SAII está desactivado tras el reinicio")
            .setContentText("Toca para reactivar la escucha")
            .setContentIntent(open).setAutoCancel(true).build()
        if (NotificationManagerCompat.from(context).areNotificationsEnabled()) {
            NotificationManagerCompat.from(context).notify(NOTIF_ID, n)
        }
    }

    companion object {
        const val CHANNEL = "saii_boot"
        const val NOTIF_ID = 2001
    }
}
