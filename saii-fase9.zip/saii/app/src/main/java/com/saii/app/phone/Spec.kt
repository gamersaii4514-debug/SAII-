package com.saii.app.phone

import org.json.JSONArray
import org.json.JSONObject

internal fun pStr(d: String) = JSONObject().put("type", "string").put("description", d)
internal fun pNum(d: String) = JSONObject().put("type", "number").put("description", d)
internal fun pChoice(d: String, vararg v: String) =
    JSONObject().put("type", "string").put("description", d).put("enum", JSONArray(v.toList()))

internal fun toolSpec(
    name: String, description: String,
    props: List<Pair<String, JSONObject>> = emptyList(), required: List<String> = emptyList(),
): JSONObject {
    val p = JSONObject().also { o -> props.forEach { (k, v) -> o.put(k, v) } }
    return JSONObject().put("name", name).put("description", description).put(
        "input_schema",
        JSONObject().put("type", "object").put("properties", p).put("required", JSONArray(required)),
    )
}
