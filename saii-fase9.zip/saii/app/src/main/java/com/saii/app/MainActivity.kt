package com.saii.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.saii.app.activation.WakeService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.saii.app.core.SaiiViewModel
import com.saii.app.shortcuts.ShortcutInstaller
import com.saii.app.ui.SaiiApp
import com.saii.app.ui.Screen
import com.saii.app.ui.SaiiTheme
import androidx.compose.runtime.mutableStateOf

class MainActivity : ComponentActivity() {

    private val vm: SaiiViewModel by viewModels()
    private val screen = mutableStateOf(Screen.HUB)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ShortcutInstaller.publishDynamic(this)
        routeIntent(intent)
        setContent {
            SaiiTheme { SaiiApp(vm = vm, screen = screen) }
        }
    }

    override fun onStart() {
        super.onStart()
        androidx.core.app.NotificationManagerCompat.from(this).cancel(com.saii.app.activation.BootReceiver.NOTIF_ID)
        WakeService.setUiVisible(true)   // la interfaz usa el micrófono: se pausa la escucha de fondo
        val wantsWake = getSharedPreferences("saii_settings", MODE_PRIVATE).getBoolean("wake_enabled", false)
        val micOk = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (wantsWake && micOk && !WakeService.active.value) {
            runCatching { WakeService.start(this) }   // recuperación tras reinicio: con la app visible Android lo permite
        }
    }

    override fun onStop() {
        super.onStop()
        vm.stopVoice()
        WakeService.setUiVisible(false)  // al salir de la app se reanuda «Hey SAII»
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        routeIntent(intent)
    }

    private fun routeIntent(i: Intent?) {
        when (i?.action) {
            ShortcutInstaller.ACTION_CHAT -> screen.value = Screen.CHAT
            ShortcutInstaller.ACTION_HUB -> screen.value = Screen.HUB
        }
    }
}
