package com.saii.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.saii.app.core.SaiiViewModel
import kotlinx.coroutines.launch

@Composable
fun BrainScreen(vm: SaiiViewModel, onBack: () -> Unit) {
    val brain by vm.brain.collectAsStateWithLifecycle()
    var key by remember { mutableStateOf("") }
    var status by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        TextButton(onClick = onBack) { Text("‹ SAII") }
        Text("Cerebro de IA", style = MaterialTheme.typography.headlineSmall)
        Text(
            if (brain.isConnected) "Estado: clave guardada" else "Estado: sin clave (no conectado)",
            color = MaterialTheme.colorScheme.primary,
        )
        Text(
            "SAII usa la API de Anthropic (modelo Claude). Necesitas una clave de API de tu cuenta en console.anthropic.com. " +
                "El uso de la API se factura aparte de cualquier plan de la app de Claude. " +
                "La clave se guarda cifrada en este teléfono (Android Keystore) y solo se envía a api.anthropic.com.",
            style = MaterialTheme.typography.bodySmall,
        )

        OutlinedTextField(
            value = key,
            onValueChange = { key = it },
            label = { Text("Clave de API") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth(),
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                enabled = key.isNotBlank() && !testing,
                onClick = {
                    vm.saveKey(key); key = ""
                    testing = true; status = "Probando conexión…"
                    scope.launch {
                        val err = vm.testBrain()
                        status = err ?: "Conexión verificada. SAII ya puede responder."
                        testing = false
                    }
                },
            ) { Text("Guardar y probar") }
            OutlinedButton(
                enabled = brain.isConnected && !testing,
                onClick = { vm.clearKey(); status = "Clave eliminada." },
            ) { Text("Eliminar clave") }
        }

        status?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
    }
}
