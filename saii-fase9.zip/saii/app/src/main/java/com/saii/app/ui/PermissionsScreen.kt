package com.saii.app.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import com.saii.app.security.PermissionEntry
import com.saii.app.security.PermissionRegistry

@Composable
fun PermissionsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }   // fuerza relectura del estado real
    var pending by remember { mutableStateOf<PermissionEntry?>(null) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    // Al volver de Ajustes se vuelve a leer el estado.
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TextButton(onClick = onBack) { Text("‹ SAII") }
        Text("Permisos", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Estado real leído del sistema. Android solo permite revocar desde Ajustes.",
            style = MaterialTheme.typography.bodySmall,
        )
        Spacer(Modifier.height(12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(PermissionRegistry.entries) { e ->
                val granted = remember(tick) { PermissionRegistry.isGranted(ctx, e) }
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(e.app, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            Text(
                                if (granted) "Concedido" else "No concedido",
                                color = if (granted) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                style = MaterialTheme.typography.labelMedium,
                            )
                        }
                        Text("Habilita: ${e.enables}", style = MaterialTheme.typography.bodySmall)
                        Text("Se usará desde la Fase ${e.phase}", style = MaterialTheme.typography.labelSmall)
                        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { pending = e }, enabled = !granted) { Text("Autorizar") }
                            OutlinedButton(onClick = {
                                ctx.startActivity(
                                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            }, enabled = granted) { Text("Revocar (Ajustes)") }
                        }
                    }
                }
            }
        }
    }

    pending?.let { e ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("Autorizar ${e.app}") },
            text = { Text("SAII lo usará para: ${e.enables}. Puedes revocarlo cuando quieras.") },
            confirmButton = {
                TextButton(onClick = {
                    if (e.permission == PermissionRegistry.WRITE_SETTINGS_KEY) {
                        ctx.startActivity(
                            Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } else if (e.permission == PermissionRegistry.NOTIFICATION_LISTENER_KEY) {
                        ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } else launcher.launch(e.permission)
                    pending = null
                }) { Text("Continuar") }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("Cancelar") } },
        )
    }
}
