package com.saii.app.core

import android.content.Context
import com.saii.app.storage.ConversationStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

/**
 * SAII_Core / SAII_Storage. Única fuente de verdad de las conversaciones, compartida por la
 * interfaz (ViewModel) y el servicio de activación por voz, que corren en el mismo proceso.
 */
object ConversationRepository {
    private const val MAX_MESSAGES = 500
    private const val MAX_CONVERSATIONS = 100

    val flow = MutableStateFlow<List<Conversation>>(emptyList())
    private var store: ConversationStore? = null
    private var loaded = false

    @Synchronized
    fun init(context: Context) {
        if (loaded) return
        val s = ConversationStore(context.applicationContext)
        store = s
        flow.value = s.load().sortedByDescending { it.updatedAt }
        loaded = true
    }

    @Synchronized
    fun save() { store?.save(flow.value) }

    /** Crea una conversación nueva al principio de la lista y devuelve su id. */
    fun create(): String {
        val c = Conversation()
        flow.update { (listOf(c) + it).take(MAX_CONVERSATIONS) }
        return c.id
    }

    fun append(id: String, m: Message, titleFrom: String? = null) {
        flow.update { list ->
            list.map { c ->
                if (c.id != id) c else c.copy(
                    title = if (c.messages.isEmpty() && titleFrom != null) titleFrom.take(40) else c.title,
                    messages = (c.messages + m).takeLast(MAX_MESSAGES),   // acota el tamaño del archivo
                    updatedAt = m.ts,
                )
            }.sortedByDescending { it.updatedAt }
        }
    }

    @Synchronized
    fun clearAll() { flow.value = emptyList(); store?.save(emptyList()) }

    fun messages(id: String): List<Message> = flow.value.firstOrNull { it.id == id }?.messages.orEmpty()
}
