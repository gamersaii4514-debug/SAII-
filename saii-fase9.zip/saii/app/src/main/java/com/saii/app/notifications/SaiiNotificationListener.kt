package com.saii.app.notifications

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** SAII_Notifications. Solo funciona si el usuario concede «Acceso a notificaciones» en Ajustes. */
class SaiiNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() { NotificationBuffer.connected = true }

    override fun onListenerDisconnected() { NotificationBuffer.connected = false }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))
            ?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        NotificationBuffer.add(
            NotificationBuffer.Entry(sbn.packageName, title.take(120), text.take(300), sbn.postTime)
        )
    }
}
