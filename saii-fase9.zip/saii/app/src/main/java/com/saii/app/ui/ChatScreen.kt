package com.saii.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.saii.app.core.Role
import com.saii.app.core.SaiiState
import com.saii.app.core.SaiiViewModel

@Composable
fun ChatScreen(vm: SaiiViewModel, onBack: () -> Unit) {
    val conversations by vm.conversations.collectAsStateWithLifecycle()
    val currentId by vm.currentId.collectAsStateWithLifecycle()
    val state by vm.state.collectAsStateWithLifecycle()
    val brain by vm.brain.collectAsStateWithLifecycle()
    val current = conversations.firstOrNull { it.id == currentId }
    var input by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    val speakReplies by vm.speakReplies.collectAsStateWithLifecycle()
    val continuous by vm.continuous.collectAsStateWithLifecycle()
    val partial by vm.partial.collectAsStateWithLifecycle()
    val notice by vm.notice.collectAsStateWithLifecycle()

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.startListening()
        else Toast.makeText(ctx, "Sin permiso de micrófono SAII no puede escucharte.", Toast.LENGTH_LONG).show()
    }
    LaunchedEffect(notice) {
        notice?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show(); vm.clearNotice() }
    }
    val listState = rememberLazyListState()

    LaunchedEffect(current?.messages?.size) {
        val n = current?.messages?.size ?: 0
        if (n > 0) listState.animateScrollToItem(n - 1)
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ SAII") }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { vm.newConversation() }) { Text("+ Nueva") }
        }

        if (conversations.isNotEmpty()) {
            LazyRow(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(conversations, key = { it.id }) { c ->
                    FilterChip(
                        selected = c.id == currentId,
                        onClick = { vm.select(c.id) },
                        label = { Text(c.title, maxLines = 1) },
                    )
                }
            }
        }

        if (!brain.isConnected) {
            Text(
                "Cerebro de IA sin clave. Añádela en SAII › Cerebro de IA para que pueda responder.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(12.dp),
            )
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(current?.messages.orEmpty(), key = { it.id }) { m ->
                val mine = m.role == Role.USER
                Box(Modifier.fillMaxWidth(), contentAlignment = if (mine) Alignment.CenterEnd else Alignment.CenterStart) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (mine) MaterialTheme.colorScheme.primary
                        else if (m.error) MaterialTheme.colorScheme.errorContainer
                        else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (mine) MaterialTheme.colorScheme.onPrimary
                        else if (m.error) MaterialTheme.colorScheme.onErrorContainer
                        else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.widthIn(max = 300.dp),
                    ) { Text(m.text, Modifier.padding(12.dp)) }
                }
            }
        }

        if (state != SaiiState.IDLE) {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp))
                Text(
                    if (state == SaiiState.LISTENING && partial.isNotBlank()) "Escuchando: $partial" else state.label,
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.weight(1f),
                )
                if (state == SaiiState.LISTENING || state == SaiiState.SPEAKING) {
                    TextButton(onClick = { vm.stopVoice() }) {
                        Text(if (state == SaiiState.LISTENING) "Cancelar" else "Callar")
                    }
                }
            }
        }

        Row(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = speakReplies, onClick = { vm.setSpeakReplies(!speakReplies) }, label = { Text("Respuestas en voz") })
            FilterChip(selected = continuous, onClick = { vm.setContinuous(!continuous) }, label = { Text("Conversación continua") })
        }

        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            // Adjuntos: pendientes (no simulados).
            TextButton(
                enabled = state != SaiiState.THINKING && state != SaiiState.EXECUTING,
                onClick = {
                    if (state == SaiiState.LISTENING) vm.stopVoice()
                    else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                        vm.startListening()
                    else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                },
            ) { Text(if (state == SaiiState.LISTENING) "Parar" else "Hablar") }
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Escribe a SAII…") },
                maxLines = 4,
            )
            Spacer(Modifier.width(6.dp))
            Button(
                onClick = { vm.send(input); input = "" },
                enabled = input.isNotBlank() && state != SaiiState.THINKING && state != SaiiState.EXECUTING,
            ) { Text("Enviar") }
        }
    }
}
