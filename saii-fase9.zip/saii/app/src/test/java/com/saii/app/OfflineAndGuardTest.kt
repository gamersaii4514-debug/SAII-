package com.saii.app

import com.saii.app.memory.SensitiveGuard
import com.saii.app.phone.LocalCommand
import com.saii.app.phone.OfflineCommands
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class OfflineAndGuardTest {
    private fun p(s: String) = OfflineCommands.parse(s)

    @Test fun flashlight() {
        assertEquals(LocalCommand("flashlight", mapOf("on" to true)), p("Enciende la linterna"))
        assertEquals(LocalCommand("flashlight", mapOf("on" to false)), p("apaga la linterna"))
        assertEquals(LocalCommand("flashlight", mapOf("on" to true)), p("SAII, activa la linterna"))
        assertNull(p("la linterna"))                       // ambiguo: no se adivina
    }

    @Test fun batteryAndTime() {
        assertEquals("get_battery", p("¿Cuánta batería queda?")?.tool)
        assertEquals("get_datetime", p("¿Qué hora es?")?.tool)
        assertEquals("get_datetime", p("qué día es hoy")?.tool)
    }

    @Test fun volume() {
        assertEquals(LocalCommand("set_volume", mapOf("action" to "up")), p("sube el volumen"))
        assertEquals(LocalCommand("set_volume", mapOf("action" to "down")), p("baja el volumen"))
        assertEquals(LocalCommand("set_volume", mapOf("action" to "set", "percent" to 40)), p("pon el volumen al 40"))
        assertEquals(LocalCommand("set_volume", mapOf("action" to "mute")), p("silencia el volumen"))
    }

    @Test fun brightness() {
        assertEquals(LocalCommand("set_brightness", mapOf("percent" to 30)), p("brillo al 30 por ciento"))
        assertEquals(LocalCommand("set_brightness", mapOf("percent" to 100)), p("pon el brillo al máximo"))
    }

    @Test fun timers() {
        assertEquals(LocalCommand("set_timer", mapOf("seconds" to 300)), p("pon un temporizador de 5 minutos"))
        assertEquals(LocalCommand("set_timer", mapOf("seconds" to 300)), p("temporizador de cinco minutos"))
        assertEquals(LocalCommand("set_timer", mapOf("seconds" to 5400)), p("temporizador de una hora y media hora"))
        assertEquals(LocalCommand("set_timer", mapOf("seconds" to 1800)), p("temporizador de media hora"))
        assertNull(p("temporizador"))
    }

    @Test fun alarms() {
        assertEquals(LocalCommand("set_alarm", mapOf("hour" to 6, "minute" to 30)), p("pon una alarma a las 6:30"))
        assertEquals(LocalCommand("set_alarm", mapOf("hour" to 18, "minute" to 0)), p("alarma a las 6 de la tarde"))
        assertEquals(LocalCommand("set_alarm", mapOf("hour" to 7, "minute" to 30)), p("alarma a las siete y media"))
        assertNull(p("pon una alarma"))
        assertNull(p("alarma a las 25"))
    }

    @Test fun openApps() {
        assertEquals(LocalCommand("open_app", mapOf("name" to "whatsapp")), p("abre WhatsApp"))
        assertEquals(LocalCommand("open_app", mapOf("name" to "youtube")), p("abre la aplicación de YouTube"))
        assertEquals("open_photos", p("abre mis fotos")?.tool)
        assertNull(p("abre whatsapp y envíale un mensaje a Carlos"))   // orden compuesta: necesita el modelo
    }

    @Test fun unknownIsNull() {
        assertNull(p("cuéntame un chiste"))
        assertNull(p(""))
        assertNull(p("llama a mamá"))
        assertNotNull(OfflineCommands.HELP)
    }

    @Test fun sensitiveGuard() {
        assertNotNull(SensitiveGuard.reason("Mi tarjeta es 4111 1111 1111 1111"))
        assertNotNull(SensitiveGuard.reason("mi contraseña del wifi es abc"))
        assertNotNull(SensitiveGuard.reason("el PIN es 1234"))
        assertNotNull(SensitiveGuard.reason("cuenta 1234567890123"))
        assertNull(SensitiveGuard.reason("mi cel es 300 123 4567"))
        assertNull(SensitiveGuard.reason("nací el 2026-11-23 16:40"))
        assertNull(SensitiveGuard.reason("voy a la clase de spin"))
        assertNull(SensitiveGuard.reason("prefiero respuestas cortas"))
    }
}
