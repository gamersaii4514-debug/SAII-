package com.saii.app

import com.saii.app.activation.WakeWord
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WakeWordTest {
    @Test fun matchesCommonTranscriptions() {
        listOf("Hey SAII", "oye saii", "SAII", "hey sai", "Oye Sai, ¿estás ahí?", "say i", "sai i").forEach {
            assertTrue(it, WakeWord.matches(it))
        }
    }

    @Test fun ignoresUnrelatedSpeech() {
        listOf("", "buenos días", "enciende la linterna", "qué hora es").forEach { assertFalse(it, WakeWord.matches(it)) }
    }

    @Test fun stripWakeReturnsTheCommand() {
        assertEquals("enciende la linterna", WakeWord.stripWake("Hey SAII, enciende la linterna"))
        assertEquals("", WakeWord.stripWake("SAII"))
        assertEquals("llama a mama", WakeWord.stripWake("oye say i llama a mamá"))
    }

    @Test fun yesNoErrsTowardsNo() {
        assertEquals(true, WakeWord.yesNo("sí"))
        assertEquals(true, WakeWord.yesNo("Sí, confirmo"))
        assertEquals(false, WakeWord.yesNo("no"))
        assertEquals(false, WakeWord.yesNo("sí pero no"))      // si aparece un «no», gana el «no»
        assertNull(WakeWord.yesNo("mmm"))
        assertNull(WakeWord.yesNo(""))
    }

    @Test fun endPhrases() {
        assertTrue(WakeWord.isEndPhrase("Gracias"))
        assertTrue(WakeWord.isEndPhrase("nada más"))
        assertFalse(WakeWord.isEndPhrase("gracias por la hora"))
    }
}
