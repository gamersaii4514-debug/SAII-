package com.saii.app

import com.saii.app.activation.ClapAnalyzer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin

/** Audio sintético a 16 kHz: ruido ambiente, aplausos (ráfaga que decae en ~12 ms) y voz/tono sostenidos. */
class ClapAnalyzerTest {
    private val sr = 16_000

    private fun noise(seconds: Double, level: Double, r: Random) = DoubleArray((sr * seconds).toInt()) { r.nextGaussian() * level }

    private fun clap(sig: DoubleArray, atMs: Int, amp: Double, r: Random) {
        val i0 = atMs * sr / 1000
        for (k in 0 until (0.15 * sr).toInt()) {
            if (i0 + k >= sig.size) break
            sig[i0 + k] += r.nextGaussian() * exp(-(k * 1000.0 / sr) / 12.0) * amp
        }
    }

    private fun speech(sig: DoubleArray, atMs: Int, durMs: Int, amp: Double) {
        val i0 = atMs * sr / 1000
        val n = minOf(durMs * sr / 1000, sig.size - i0)
        val v = DoubleArray(n) { k ->
            val t = k.toDouble() / sr
            (1..7).sumOf { h -> sin(2 * PI * 150 * h * t) / h } * (0.6 + 0.4 * sin(2 * PI * 4 * t))
        }
        val peak = v.maxOf { abs(it) }
        for (k in 0 until n) sig[i0 + k] += v[k] / peak * amp
    }

    private fun hits(sig: DoubleArray, sens: Int = 50, gap: Int = 700): Int {
        val a = ClapAnalyzer(sens, gap)
        val buf = ShortArray(320)
        var count = 0
        var k = 0
        while (k + 320 <= sig.size) {
            for (j in 0 until 320) buf[j] = (sig[k + j].coerceIn(-1.0, 1.0) * 32767).toInt().toShort()
            if (a.process(buf, 320)) count++
            k += 320
        }
        return count
    }

    /** Número de ensayos (de 20, con semillas distintas) en los que se detectó al menos un doble aplauso. */
    private fun trials(noise: Double = 0.005, sens: Int = 50, build: (DoubleArray, Random) -> Unit): Int =
        (1..20).count { seed ->
            val r = Random(seed.toLong())
            val s = noise(4.0, noise, r)
            build(s, r)
            hits(s, sens) >= 1
        }

    @Test fun doubleClapLoudIsDetected() =
        assertEquals(20, trials { s, r -> clap(s, 1000, 0.6, r); clap(s, 1350, 0.6, r) })

    @Test fun doubleClapSoftIsDetected() =
        assertTrue(trials { s, r -> clap(s, 1000, 0.2, r); clap(s, 1400, 0.2, r) } >= 18)

    @Test fun doubleClapWithBackgroundNoiseIsDetected() =
        assertTrue(trials(noise = 0.02) { s, r -> clap(s, 1000, 0.6, r); clap(s, 1400, 0.6, r) } >= 18)

    @Test fun doubleClapAt600msIsDetected() =
        assertTrue(trials { s, r -> clap(s, 1000, 0.6, r); clap(s, 1600, 0.6, r) } >= 18)

    @Test fun singleClapIsIgnored() = assertEquals(0, trials { s, r -> clap(s, 1000, 0.6, r) })

    @Test fun echoSeparatedBy80msIsIgnored() =
        assertEquals(0, trials { s, r -> clap(s, 1000, 0.6, r); clap(s, 1080, 0.6, r) })

    @Test fun clapsTooFarApartAreIgnored() =
        assertEquals(0, trials { s, r -> clap(s, 1000, 0.6, r); clap(s, 2000, 0.6, r) })

    @Test fun threeClapsAreIgnored() =
        assertEquals(0, trials { s, r -> clap(s, 1000, 0.6, r); clap(s, 1350, 0.6, r); clap(s, 1700, 0.6, r) })

    @Test fun sustainedSpeechIsIgnored() = assertEquals(0, trials { s, _ -> speech(s, 1000, 1200, 0.3) })

    // Dos sonidos LARGOS (300 ms) con el intervalo de un doble aplauso: solo el límite de duración los descarta.
    @Test fun twoLongBurstsAreNotClaps() =
        assertEquals(0, trials { s, _ -> speech(s, 1000, 300, 0.3); speech(s, 1500, 300, 0.3) })

    @Test fun continuousToneIsIgnored() = assertEquals(0, trials { s, _ -> speech(s, 500, 3000, 0.3) })

    @Test fun backgroundNoiseAloneIsIgnored() = assertEquals(0, trials { _, _ -> })

    @Test fun noFalsePositivesInTwoMinutesOfSpeechAndNoise() {
        val r = Random(99)
        val s = noise(120.0, 0.008, r)
        var at = 2000
        while (at < 115_000) { speech(s, at, 500 + r.nextInt(2000), 0.1 + r.nextDouble() * 0.3); at += 6000 }
        assertEquals(0, hits(s))
    }

    @Test fun lowSensitivityMissesSoftClapsHighSensitivityCatchesThem() {
        val build = { s: DoubleArray, r: Random -> clap(s, 1000, 0.1, r); clap(s, 1400, 0.1, r) }
        assertEquals(0, trials(sens = 0, build = build))
        assertTrue(trials(sens = 90, build = build) >= 18)
    }
}
