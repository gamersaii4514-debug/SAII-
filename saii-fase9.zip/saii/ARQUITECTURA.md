# SAII — Análisis y arquitectura

## 1. Restricciones reales de Android (lo que condiciona el diseño)

| Requisito | Realidad en Android | Decisión |
|---|---|---|
| Carpeta personalizada en el launcher | Las apps no pueden crear carpetas en el launcher. Solo *shortcuts* (estáticos, dinámicos, fijados). | App principal + acceso directo fijado + **Hub SAII** interno que se ve como carpeta (Fase 1). |
| "Hey SAII" en segundo plano | Requiere un *foreground service* con notificación persistente y permiso de micrófono (Android 14+: tipo `microphone`, solo iniciable con la app visible o tras acción del usuario). Para una palabra de activación propia hace falta un motor on-device (Porcupine/openWakeWord). | Fase 4. Servicio en primer plano + motor de wake word offline. |
| Dos aplausos | Mismo servicio de micrófono. Se detecta con `AudioRecord` + análisis de energía/pico (RMS, intervalo 150–800 ms). Sin reconocimiento de voz hasta confirmar. | Fase 5. Muy ligero en CPU. |
| Linterna, volumen, brillo, batería, alarmas, temporizadores | APIs oficiales: `CameraManager.setTorchMode`, `AudioManager`, `Settings.System` (requiere WRITE_SETTINGS), `BatteryManager`, `AlarmClock` intents. | Fase 6. |
| Llamadas / SMS | `ACTION_DIAL` sin permiso; `CALL_PHONE` y `SEND_SMS` con permiso y confirmación. | Fase 6, siempre con confirmación. |
| WhatsApp / Facebook / Telegram | **No tienen API pública para enviar mensajes en nombre del usuario.** Sí existen intents: WhatsApp `wa.me` / `ACTION_SEND` (abre el chat con el texto prellenado; el usuario pulsa enviar); Telegram `tg://`. | El mensaje queda **preparado** y el usuario toca enviar. No se simulará envío automático. |
| Google Home | Home APIs para Android (Google) con OAuth/permisos propios. | Fase 7. |
| Gmail, Calendar, Drive, Contacts, Maps | APIs oficiales con OAuth (necesita proyecto en Google Cloud). | Fase 7. |
| Cerebro IA | Modelo en la nube vía API (p. ej. Claude API) con *tool use*, para que el modelo pida acciones y SAII las ejecute con permisos. | Fase 2. La clave NO va en el APK final: proxy propio o clave del usuario en almacenamiento cifrado. |
| Reiniciar teléfono | `BOOT_COMPLETED` receiver para relanzar servicios. | Fase 4/9. |

## 2. Arquitectura modular

Fase 1 usa un solo módulo Gradle (`:app`) con paquetes por módulo, para no complicar el build en equipos modestos. Cada paquete expone solo interfaces hacia `core`; se separarán en módulos Gradle cuando cada uno tenga contenido real.

```
com.saii.app
├─ core/        SAII_Core        Núcleo: bus de eventos, registro de módulos, orquestador
├─ ai/          SAII_AI          Interfaz Brain (Fase 2). Hoy: sin proveedor → estado "no conectado"
├─ voice/       SAII_Voice       (Fase 3)
├─ activation/  SAII_Activation / SAII_ClapDetector  (Fases 4-5)
├─ memory/      SAII_Memory      (Fase 8)
├─ phone/       SAII_Android     Acciones del teléfono con herramientas del cerebro (Fase 6)
├─ integrations/ Google/WhatsApp/Facebook/Communication (Fase 7)
├─ automation/  SAII_Automation  (Fase 8)
├─ security/    SAII_Security    Registro de permisos y confirmaciones (base en Fase 1)
├─ storage/     SAII_Storage     Persistencia de conversaciones (Fase 1)
└─ ui/          SAII_UI          Compose: Hub + Chat (Fase 1)
```

Regla: toda acción pasa por `core` → `security` (¿permiso? ¿requiere confirmación?) → módulo ejecutor. Nada se ejecuta saltándose ese camino.

## 3. Alcance de la Fase 1 (lo implementado)

- App Android (Kotlin + Jetpack Compose, minSdk 26).
- Icono propio y acceso directo: estático (mantener pulsado el icono), dinámico y botón para **fijarlo en la pantalla principal**.
- **Hub SAII**: pantalla tipo carpeta con las 12 secciones pedidas. Las secciones sin implementar aparecen marcadas «Fase N», sin fingir funcionamiento.
- **Chat**: escribir, enviar, historial persistente en disco (JSON), estados visibles (escuchando / pensando / ejecutando), múltiples conversaciones.
- **Panel de permisos** base: lista de permisos planeados con estado real (concedido/no) leído del sistema.
- Cerebro IA: **no conectado**. SAII lo dice claramente. Se conecta en Fase 2.

Pendiente en Fase 1 (honesto): adjuntar imágenes/documentos (se hace con el cerebro en Fase 2, porque sin modelo no hay qué analizar) y botón de voz (Fase 3; el botón existe deshabilitado).

## 4. Pruebas de Fase 1
1. Instala, abre: se ve el Hub.
2. Fija el acceso directo desde el Hub; ciérralo; el icono sigue en la pantalla principal.
3. Escribe un mensaje; reinicia la app; la conversación persiste.
4. Permisos: concede/revoca desde Ajustes y comprueba que el panel refleja el estado.

---

## 5. Estado al cerrar la Fase 9

| Módulo | Paquete | Estado |
|---|---|---|
| SAII_Core | `core/` | Orquestación, estado, modo sin conexión (`Net`, `OfflineCommands`) |
| SAII_AI | `ai/` | Cerebro Claude con uso de herramientas, búsqueda web, pausa de turno |
| SAII_Voice | `voice/` | Reconocimiento y síntesis del sistema |
| SAII_ClapDetector | `activation/Clap*` | Probado con audio sintético (no con micrófono real) |
| SAII_Activation | `activation/` | «Hey SAII», aplausos, servicio en primer plano, aviso tras reinicio |
| SAII_Memory | `memory/` | Recuerdos, historial, rutinas, filtro de datos sensibles |
| SAII_Android | `phone/` | Linterna, volumen, brillo, batería, alarmas, apps, llamadas, SMS, multimedia |
| SAII_Google / WhatsApp / Facebook / Communication | `phone/Integrations.kt` | Solo por intents y proveedores públicos; mensajes siempre «preparados» |
| SAII_Automation | `phone/AutomationTools.kt`, `memory/RoutineStore.kt` | Rutinas a pedido |
| SAII_Security | `security/`, `storage/KeyVault.kt`, `Confirmer` | Permisos transparentes, confirmaciones, clave cifrada |
| SAII_Notifications | `notifications/` | Buffer en RAM de notificaciones, solo con acceso concedido |
| SAII_Storage | `memory/JsonFile.kt`, `storage/` | JSON atómico en almacenamiento privado |
| SAII_UI | `ui/` | Hub, chat, permisos, activación, integraciones, memoria, historial, automatizaciones, datos |
| SAII_Internet | `ai/ClaudeBrain.kt` | Búsqueda web de la API (facturada aparte) |

Decisiones de seguridad en el código (no delegadas al modelo): confirmación obligatoria para llamadas y SMS (ante la duda, «no»);
filtro de datos sensibles en la memoria; resultados de herramientas tratados como datos, no órdenes; HTTPS obligatorio;
`allowBackup=false`; clave en el Keystore; límites de pasos (6 por respuesta, 10 por rutina) y de tamaño (500 mensajes por
conversación, 200 recuerdos, 200 acciones en el historial).

Pendiente real: adjuntos en el chat, streaming, programación de rutinas por hora, Google Home/Gmail/Drive (requieren credenciales
del usuario), y sobre todo **ejecutar y corregir todo en un teléfono** (ver `PRUEBAS.md`).
