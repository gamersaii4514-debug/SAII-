# SAII — Plan de pruebas y estado real

Ninguna fase se ha ejecutado todavía en un teléfono: el código se escribió sin Android SDK. Lo único verificado
con ejecución real es la lógica pura (ver «Pruebas automáticas»). Todo lo demás está **sin probar**: usa esta lista
en orden; si una fila falla, anota el mensaje o el error de compilación y corrígelo antes de seguir.

## Compilar
1. Android Studio (Ladybug o superior), JDK 17. Abrir la carpeta `saii`, esperar el *Sync*.
2. Conectar el teléfono con depuración USB y pulsar *Run*.
3. Si el *Sync* o la compilación fallan: copiar el primer error completo. Los errores de tipos de Kotlin son lo más probable.

## Pruebas automáticas (lógica pura, 28 pruebas)
`./gradlew testDebugUnitTest` — cubre: detector de dos aplausos con audio sintético (incluye casos que NO deben activarlo:
un golpe, eco, tres aplausos, voz, tono continuo, 2 min de habla con ruido), palabra de activación, sí/no de confirmaciones,
órdenes sin conexión y filtro de datos sensibles. Se comprobó, rompiendo el detector a propósito, que las pruebas fallan cuando deben.
No cubren: micrófono real, Android, red ni la interfaz.

## Pruebas manuales por fase
| Fase | Prueba | Resultado esperado |
|---|---|---|
| 1 | Abrir SAII; «Fijar SAII en la pantalla principal»; cerrar | El icono queda en la pantalla principal |
| 1 | Escribir un mensaje y reiniciar la app | La conversación sigue ahí |
| 2 | Cerebro de IA → pegar clave → «Guardar y probar» | «Conexión verificada» |
| 2 | Modo avión + escribir | Aviso rojo; SAII no inventa respuesta |
| 3 | «Hablar» y decir una pregunta | Se ve lo que oye, responde por texto y voz |
| 4 | Activar «Hey SAII»; cerrar la app; decir «Hey SAII» | «A sus órdenes», atiende la orden y sigue la conversación |
| 5 | Método «Dos aplausos» → «Probar aplausos» | El contador sube con dos aplausos, no con uno ni con voz |
| 5 | Escucha activa, cerrar la app, dos aplausos y «SAII» | «Aquí estoy, dime» |
| 6 | «Enciende la linterna», «volumen al 40», «¿cuánta batería queda?» | Lo hace y lo cuenta |
| 6 | «Llama a <contacto>» | Diálogo con nombre y número; Cancelar no llama |
| 6 | Cerrar SAII y pedir «abre YouTube» por voz | Notificación para tocar; el resultado dice «todavía NO está hecho» |
| 7 | «Prepárale a <contacto> un WhatsApp diciendo que llego tarde» | Abre el chat con el texto; NO lo envía |
| 7 | «¿Qué tengo en el calendario esta semana?» (con permiso) | Lista tus eventos |
| 7 | «Apaga las luces de mi cuarto» | Dice que no puede (Google Home no está disponible) |
| 8 | «Recuerda que prefiero respuestas cortas»; chat nuevo | Aparece en Memoria y lo respeta |
| 8 | «Recuerda que mi contraseña es abc» | Se niega |
| 8 | Crear y ejecutar una rutina; decir su nombre | Ejecuta los pasos e informa cada resultado |
| 9 | Modo avión y «enciende la linterna» | Funciona sin Internet |
| 9 | Modo avión y «cuéntame un chiste» | Explica qué órdenes sí puede hacer sin conexión |
| 9 | Reiniciar el teléfono con la escucha activada | Notificación «SAII está desactivado tras el reinicio»; al tocarla se reactiva |
| 9 | Escucha por voz con batería ≤ 15 % sin cargar | Notificación «En pausa: batería baja» |
| 9 | Hub → Configuraciones: cambiar «Responder en voz» y abrir «Optimización de batería» | Los interruptores se conservan; abre la pantalla del sistema |
| 9 | Archivos de SAII → «Borrar todos mis datos» | Conversaciones, recuerdos, rutinas e historial vacíos; la clave sigue |

## Limitaciones conocidas (no son errores)
- **Google Home, Gmail (leer), Drive:** no disponibles; requieren proyecto de Google Cloud y OAuth que solo el usuario puede crear.
- **WhatsApp, Telegram, Messenger, Facebook:** no existe API pública para enviar por el usuario; SAII deja el mensaje preparado.
- **Segundo plano:** Android bloquea abrir pantallas desde un servicio; SAII deja una notificación para tocar.
- **Reinicio:** Android no permite arrancar el micrófono al encender; hace falta un toque en la notificación.
- **«Hey SAII» y aplausos a la vez:** el micrófono no se comparte; se elige un método.
- **«Hey SAII» consume batería** (reconocimiento continuo, por elección del usuario). Los aplausos consumen mucho menos.
- **Rutinas:** solo a pedido, sin programación por hora.
- **Adjuntar imágenes y documentos al chat:** no implementado.
- **Respuestas por streaming (palabra a palabra):** no implementado; la respuesta llega completa.
- **Costos:** la API de Anthropic y la búsqueda web se facturan aparte en tu cuenta.
- **Distribución:** si algún día se publica en Google Play, las políticas restringen los permisos de SMS y llamadas.

## Privacidad: qué sale del teléfono
- Hacia la API de Anthropic: tus mensajes, los últimos 40 de la conversación, tus recuerdos (hasta 60) y los resultados de las
  herramientas (por ejemplo notificaciones o eventos de calendario si los pides).
- No salen: la clave (solo va a `api.anthropic.com`), el historial de actividades, las rutinas en sí (solo sus nombres) ni los archivos.
- Todo lo guardado vive en el almacenamiento privado de la app; la clave, cifrada con el Keystore de Android.
